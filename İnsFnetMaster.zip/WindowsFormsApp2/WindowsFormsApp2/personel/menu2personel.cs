﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2.personel
{
    public partial class menu2personel : Form
    {
        string connectionString = @"Data Source=.;Initial Catalog=gnc;Integrated Security=True;TrustServerCertificate=true";
        public menu2personel()
        {
            InitializeComponent();
        }

        private void textBox2_Enter(object sender, EventArgs e)
        {
            
        }

        private void textBox2_Leave(object sender, EventArgs e)
        {
           
        }

        private void textBox4_Enter(object sender, EventArgs e)
        {
           
            
        }

        private void textBox4_Leave(object sender, EventArgs e)
        {
            
        }

        private void textBox5_Enter(object sender, EventArgs e)
        {
            
        }

        private void textBox5_Leave(object sender, EventArgs e)
        {
        }

        private void textBox7_Enter(object sender, EventArgs e)
        {
           
        }

        private void textBox7_Leave(object sender, EventArgs e)
        {
            
        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {
            // Telefon numarasının maksimum uzunluğunu kontrol et
            if (textBox7.Text.Length > 11)
            {
                // Eğer 10 karakterden fazla ise son karakteri sil
                textBox7.Text = textBox7.Text.Remove(textBox7.Text.Length - 1);
                // İmleci en sona götür
                textBox7.SelectionStart = textBox7.Text.Length;
            }
        }

        private void textBox7_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void textBox1_Enter(object sender, EventArgs e)
        {
            if (textBox1.Text == "İd Giriniz")
            {
                textBox1.Text = "";
            }
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                textBox1.Text = "İd Giriniz";
            }
        }

        private void textBox3_Enter(object sender, EventArgs e)
        {
            if (textBox3.Text == "Ara")
            {
                textBox3.Text = "";
            }
        }

        private void textBox3_Leave(object sender, EventArgs e)
        {
            if (textBox3.Text == "")
            {
                textBox3.Text = "Ara";
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            string searchText = textBox3.Text;

            // Arama fonksiyonunu çağır
            SearchAndHighlight(searchText);
        }
       
        private void SearchAndHighlight(string searchText)
        {
            // DataGridView'i dolaşarak arama yapma
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                // Her bir hücreyi kontrol etme
                foreach (DataGridViewCell cell in row.Cells)
                {
                    // Hücrede aranan metni bulma
                    if (cell.Value != null && cell.Value.ToString().IndexOf(searchText, StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        // Eğer aranan metin bulunduysa, hücreyi ve ilgili sütunu gösterme
                        dataGridView1.CurrentCell = cell;
                        dataGridView1.FirstDisplayedScrollingRowIndex = row.Index;
                        dataGridView1.Columns[cell.ColumnIndex].Visible = true;

                        // Hücreyi seçme
                        dataGridView1.Rows[cell.RowIndex].Selected = true;

                        // Aramayı sonlandır
                        return;
                    }
                }
            }

            // Eğer aranan metin bulunamazsa, kullanıcıya bilgi ver
            MessageBox.Show("Aranan metin bulunamadı.");
            temizle();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            int id;
            if (int.TryParse(textBox1.Text, out id))
            {
                DeleteDataByID(id);
                LoadDataFromDatabase();
                gizle();
                temizle();
            }
            else
            {
                MessageBox.Show("Geçerli bir ID giriniz.");
            }
        }
        private void DeleteDataByID(int id)
        {
            try
            {
                // SqlConnection nesnesi oluşturma
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    // SQL sorgusu
                    string query = "DELETE FROM ucpersonel WHERE id = @ID";

                    // SqlCommand nesnesi oluşturma
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // Parametre ekleyerek SQL sorgusunu güvenli hale getirme
                        command.Parameters.AddWithValue("@ID", id);

                        // Bağlantıyı açma
                        connection.Open();

                        // Sorguyu çalıştırma
                        int rowsAffected = command.ExecuteNonQuery();

                        // Etkilenen satır sayısını kontrol etme
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Veri başarıyla silindi!");
                            LoadDataFromDatabase();
                            textBox1.Text = string.Empty;

                        }
                        else
                        {
                            MessageBox.Show("Silme işlemi başarısız oldu. Veri bulunamadı veya silinemedi.");
                            LoadDataFromDatabase();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Veri silinirken bir hata oluştu: " + ex.Message);
            }
        }

        private void menu2personel_Load(object sender, EventArgs e)
        {
            LoadDataFromDatabase();
            ResizeDataGridView();
            gizle();
            dataGridView1.ReadOnly = true;
        }
        private void ResizeDataGridView()
        {
            // Sütunların otomatik boyutlandırılmasını sağla
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            // Satırların otomatik boyutlandırılmasını sağla
            dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;


        }
        private void LoadDataFromDatabase()
        {
            try
            {
                // SqlConnection nesnesi oluşturma
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    // SQL sorgusu
                    string query = "SELECT id AS 'İD', personel_adi AS 'Adı', personel_soyadi AS 'Soyisim', personel_gorevi AS 'Görevi', personel_tel AS 'Telefon Numarası' FROM ucpersonel";

                    // SqlDataAdapter nesnesi oluşturma
                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);

                    // DataTable oluşturma ve verileri yükleme
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    // DataGridView'e verileri yükleme
                    dataGridView1.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
            }
        }
        private void gizle()
        {
            textBox1.Visible = false;
            textBox2.Visible = false;
            textBox3.Visible = false;
            button7.Visible = false;
            textBox4.Visible = false;
            textBox5.Visible = false;

            textBox7.Visible = false;
            button3.Visible = false;
            label1.Visible = false;
            label2.Visible = false;
            label3.Visible = false;
            label4.Visible = false;
            label5.Visible = false;

        }
        private void temizle()
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();

            textBox7.Clear();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            gizle();
            textBox2.Visible = true;
            textBox4.Visible = true;
            textBox5.Visible = true;
            label1.Visible = true;
            label2.Visible = true;
            label3.Visible = true;
            label4.Visible = true;
            textBox7.Visible = true;
            button3.Visible = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            gizle();
            textBox1.Visible = true;
            button7.Visible = true;
            label5.Visible = true;
            LoadDataFromDatabase();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            gizle();
            temizle();
            textBox1.Text = string.Empty;
            textBox3.Visible = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string personelAdi = textBox2.Text;
            string personelSoyadi = textBox4.Text;

            string personelgorev = textBox5.Text;
            string personelTel = textBox7.Text;

            InsertData(personelAdi, personelSoyadi, personelgorev, personelTel);
            gizle();
            temizle();
        }
        private void InsertData(string personelAdi, string personelSoyadi, string personelgorev, string personelTel)
        {
            try
            {
                // SqlConnection nesnesi oluşturma
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    // SQL sorgusu
                    string query = "INSERT INTO ucpersonel (personel_adi, personel_soyadi, personel_gorevi, personel_tel,maas,toplam_maas) VALUES (@PersonelAdi, @PersonelSoyadi, @Personelgorev, @PersonelTel,@maas,@toplam_maas); SELECT SCOPE_IDENTITY();";

                    // SqlCommand nesnesi oluşturma
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // Parametre ekleyerek SQL sorgusunu güvenli hale getirme
                        command.Parameters.AddWithValue("@PersonelAdi", personelAdi);
                        command.Parameters.AddWithValue("@PersonelSoyadi", personelSoyadi);
                        command.Parameters.AddWithValue("@Personelgorev", personelgorev);
                        command.Parameters.AddWithValue("@PersonelTel", personelTel);
                        command.Parameters.AddWithValue("@maas", 0);
                        command.Parameters.AddWithValue("@toplam_maas", 0);

                        // Bağlantıyı açma
                        connection.Open();

                        // Sorguyu çalıştırma ve eklenen kaydın ID'sini alarak geri döndürme
                        int insertedID = Convert.ToInt32(command.ExecuteScalar());

                        // Başarılı bir şekilde eklenen kaydın ID'sini gösterme
                        MessageBox.Show("Veri başarıyla eklendi! Eklenen ID: " + insertedID.ToString());
                        LoadDataFromDatabase();
                        gizle();
                        temizle();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Veri eklenirken bir hata oluştu: " + ex.Message);
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            LoadDataFromDatabase();
            gizle();
        }
    }
}
