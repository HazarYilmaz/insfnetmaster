﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        bool formTasiniyor = false;
        Point baslangicNoktasi = new Point(0, 0);

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == "__________________________" || textBox2.Text == " ")
            {
                checkBox1.Checked = false;
                textBox2.PasswordChar = '\0';
            }
            else
            {
                if (checkBox1.Checked == false)
                {
                    checkBox1.Checked = true;
                    textBox2.PasswordChar = '\0';
                }
                else if (checkBox1.Checked == true)
                {
                    checkBox1.Checked = false;
                    textBox2.PasswordChar = '*';
                }
            }
        }

        private void textBox1_Enter(object sender, EventArgs e)
        {
            if (textBox1.Text == "__________________________")
            {
                textBox1.Text = ("");
            }
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                textBox1.Text = ("__________________________");
            }
        }

        private void textBox2_Enter(object sender, EventArgs e)
        {
            if (textBox2.Text == "__________________________")
            {
                textBox2.Text = ("");
                textBox2.PasswordChar = '*';
            }
        }

        private void textBox2_Leave(object sender, EventArgs e)
        {
            if (textBox2.Text == "")
            {
                textBox2.Text = ("__________________________");
                textBox2.PasswordChar = '\0';
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            DialogResult result = MessageBox.Show("Uygulamadan Çıkmak Üzeresin Devam Etmek İstiyor Musunuz?", "Emin Misin", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (formTasiniyor)
            {
                Point p = PointToScreen(e.Location);
                Location = new Point(p.X - this.baslangicNoktasi.X, p.Y - this.baslangicNoktasi.Y);
            }
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            formTasiniyor = true;
            baslangicNoktasi = new Point(e.X, e.Y);
        }

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            formTasiniyor = false;
        }

        private void panel2_MouseDown(object sender, MouseEventArgs e)
        {
            formTasiniyor = true;
            baslangicNoktasi = new Point(e.X, e.Y);
        }

        private void panel2_MouseUp(object sender, MouseEventArgs e)
        {
            formTasiniyor = false;
        }

        private void panel2_MouseMove(object sender, MouseEventArgs e)
        {
            if (formTasiniyor)
            {
                Point p = PointToScreen(e.Location);
                Location = new Point(p.X - this.baslangicNoktasi.X, p.Y - this.baslangicNoktasi.Y);
            }
        }

        private void label6_MouseUp(object sender, MouseEventArgs e)
        {
            formTasiniyor = false;
        }

        private void label6_MouseMove(object sender, MouseEventArgs e)
        {
            if (formTasiniyor)
            {
                Point p = PointToScreen(e.Location);
                Location = new Point(p.X - this.baslangicNoktasi.X, p.Y - this.baslangicNoktasi.Y);
            }
        }

        private void label6_MouseDown(object sender, MouseEventArgs e)
        {
            formTasiniyor = true;
            baslangicNoktasi = new Point(e.X, e.Y);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "sedatgns" && textBox2.Text == "630163")
            {
                DialogResult result = MessageBox.Show("Giriş Başarılı!", "Giriş Yapıldı", MessageBoxButtons.OK);
                if (result == DialogResult.OK)
                {
                    splash yukleme = new splash();
                    yukleme.Show();
                    this.Hide();





                }

            }
            else
            {


                DialogResult result = MessageBox.Show("Kullanıcı Adınız veya Şifreniz Yanlış Lütfen Tekrar Deneyin", "Hatalı Giriş", MessageBoxButtons.OK);

                if (result == DialogResult.OK)
                {
                    textBox1.Text = "__________________________";
                    textBox2.Text = "__________________________";
                    checkBox1.Checked = false;
                    if (checkBox1.Checked == false)
                    {
                        textBox2.PasswordChar = '\0';
                    }
                }

            }
        }
    }
}
