﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp2.menu;

namespace WindowsFormsApp2.raporlar
{
    public partial class raporlar9 : Form
    {
        public raporlar9()
        {
            InitializeComponent();
        }
        bool formTasiniyor = false;
        Point baslangicNoktasi = new Point(0, 0);
        string connectionString = @"Data Source=.;Initial Catalog=gnc;Integrated Security=True;TrustServerCertificate=true";

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            menu8 geri = new menu8();
            geri.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void panel2_MouseDown(object sender, MouseEventArgs e)
        {
            formTasiniyor = true;
            baslangicNoktasi = new Point(e.X, e.Y);
        }

        private void panel2_MouseMove(object sender, MouseEventArgs e)
        {
            if (formTasiniyor)
            {
                Point p = PointToScreen(e.Location);
                Location = new Point(p.X - this.baslangicNoktasi.X, p.Y - this.baslangicNoktasi.Y);
            }
        }

        private void panel2_MouseUp(object sender, MouseEventArgs e)
        {
            formTasiniyor = false;
        }
        private void VeriSayisiniYazdir()
        {
            //Toplam Apartman Sayısı
            try
            {
                int veriSayisi = 0;

                // SQL sorgusuyla "birapart" tablosundaki toplam veri sayısını al
                string query = "SELECT COUNT(*) FROM dokuzapart";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    connection.Open();
                    // Toplam veri sayısını al
                    veriSayisi = (int)command.ExecuteScalar();
                }

                // Toplam veri sayısını Label kontrolüne yazdır
                label5.Text = veriSayisi.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Veri sayısı alınırken bir hata oluştu: " + ex.Message);
            }
            //Akitf Apart sayısı
            try
            {
                int aktifSayisi = 0;

                // SQL sorgusuyla "birapart" tablosundaki aktif kayıt sayısını al
                string query = "SELECT COUNT(*) FROM dokuzapart WHERE durum = 'Aktif'";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    connection.Open();
                    aktifSayisi = (int)command.ExecuteScalar();
                }

                // Aktif kayıt sayısını Label kontrolüne yaz
                label1.Text = aktifSayisi.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Aktif kayıt sayısı alınırken bir hata oluştu: " + ex.Message);
            }
            //Toplam Gelir
            try
            {
                string toplamMiktar = "";

                // SQL sorgusuyla "biralacak" tablosundaki miktar sütunundaki değerlerin toplamını al
                string query = "SELECT SUM(miktar) FROM dokuzalacak";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    connection.Open();
                    // Toplam miktarı double türünde alıyoruz
                    double result = Convert.ToDouble(command.ExecuteScalar());
                    // Toplam miktarı formatlayarak stringe çeviriyoruz
                    toplamMiktar = result.ToString("N0");
                }

                // Toplam miktarın sonuna "TL" işaretini ekleyerek Label kontrolüne yaz
                label6.Text = toplamMiktar + " ₺";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Toplam miktar alınırken bir hata oluştu: " + ex.Message);
            }
            // Toplam Gider
            try
            {
                string toplamMiktar = "";

                // SQL sorgusuyla "biralacak" tablosundaki miktar sütunundaki değerlerin toplamını al
                string query = "SELECT SUM(miktar) FROM odemedokuz";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    connection.Open();
                    // Toplam miktarı double türünde alıyoruz
                    double result = Convert.ToDouble(command.ExecuteScalar());
                    // Toplam miktarı formatlayarak stringe çeviriyoruz
                    toplamMiktar = result.ToString("N0");
                }

                // Toplam miktarın sonuna "TL" işaretini ekleyerek Label kontrolüne yaz
                label7.Text = toplamMiktar + " ₺";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Toplam miktar alınırken bir hata oluştu: " + ex.Message);
            }
            //Ortalama  Gelir
            try
            {
                string ortalamaMiktar = "";

                // SQL sorgusuyla "biralacak" tablosundaki miktar sütunundaki değerlerin ortalamasını al
                string query = "SELECT AVG(miktar) FROM dokuzalacak";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    connection.Open();
                    // Ortalama miktarı double türünde alıyoruz
                    int result = Convert.ToInt32(command.ExecuteScalar());
                    // Ortalama miktarı formatlayarak stringe çeviriyoruz
                    ortalamaMiktar = result.ToString("N0"); // N0 formatı 0 ondalık basamağa kadar gösterir
                }

                // Ortalama miktarın sonuna "TL" işaretini ekleyerek Label kontrolüne yaz
                label11.Text = ortalamaMiktar + " ₺";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ortalama miktar alınırken bir hata oluştu: " + ex.Message);
            }
            //Toplam Çalışan 
            try
            {
                int calisanSayisi = 0;

                // SQL sorgusuyla "birpersonel" tablosundaki toplam çalışan sayısını al
                string query = "SELECT COUNT(*) FROM dokuzpersonel";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    connection.Open();
                    // Toplam çalışan sayısını al
                    calisanSayisi = (int)command.ExecuteScalar();
                }

                // Toplam çalışan sayısını Label kontrolüne yazdır
                label15.Text = calisanSayisi.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Çalışan sayısı alınırken bir hata oluştu: " + ex.Message);
            }
            //Ortalama Cari Gider
            try
            {
                string toplamMiktar = "";

                // SQL sorgusuyla "biralacak" tablosundaki miktar sütunundaki değerlerin toplamını al
                string query = "SELECT AVG(miktar) FROM odemedokuz";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    connection.Open();
                    // Toplam miktarı double türünde alıyoruz
                    double result = Convert.ToDouble(command.ExecuteScalar());
                    // Toplam miktarı formatlayarak stringe çeviriyoruz
                    toplamMiktar = result.ToString("N0");
                }

                // Toplam miktarın sonuna "TL" işaretini ekleyerek Label kontrolüne yaz
                label13.Text = toplamMiktar + " ₺";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Toplam miktar alınırken bir hata oluştu: " + ex.Message);
            }
            //Toplam Ödenen Maaş
            try
            {
                double toplamMaas = 0;

                // SQL sorgusuyla "birpersonel" tablosundaki maaşların toplamını al
                string query = "SELECT SUM(maas) FROM dokuzpersonel";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    connection.Open();
                    // Toplam maaşı double türünde alıyoruz
                    object result = command.ExecuteScalar();
                    if (result != DBNull.Value)
                    {
                        toplamMaas = Convert.ToDouble(result);
                    }
                }

                // Toplam maaşı Label kontrolüne yazdır
                label17.Text = toplamMaas.ToString("N0") + " ₺"; // N0 formatı 0  basamağa kadar gösterir
            }
            catch (Exception ex)
            {
                MessageBox.Show("Toplam maaş alınırken bir hata oluştu: " + ex.Message);
            }
            //Tüm Zamanların Toplam Maaşı
            try
            {
                double toplamMaas = 0;

                // SQL sorgusuyla "birpersonel" tablosundaki maaşların toplamını al
                string query = "SELECT SUM(toplam_maas) FROM dokuzpersonel";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    connection.Open();
                    // Toplam maaşı double türünde alıyoruz
                    object result = command.ExecuteScalar();
                    if (result != DBNull.Value)
                    {
                        toplamMaas = Convert.ToDouble(result);
                    }
                }

                // Toplam maaşı Label kontrolüne yazdır
                label19.Text = toplamMaas.ToString("N0") + " ₺"; // N0 formatı 0  basamağa kadar gösterir
            }
            catch (Exception ex)
            {
                MessageBox.Show("Toplam maaş alınırken bir hata oluştu: " + ex.Message);
            }

            //TOPLAM GİDERLER 
            try
            {
                double toplam = 0;

                // Birodeme tablosundaki miktarları topla
                string miktarSorgusu = "SELECT SUM(miktar) FROM odemedokuz";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand miktarCommand = new SqlCommand(miktarSorgusu, connection);
                    connection.Open();
                    object miktarResult = miktarCommand.ExecuteScalar();
                    if (miktarResult != DBNull.Value)
                    {
                        toplam += Convert.ToDouble(miktarResult);
                    }
                }

                // Birpersonel tablosundaki maaşları topla
                string maasSorgusu = "SELECT SUM(maas) FROM dokuzpersonel";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand maasCommand = new SqlCommand(maasSorgusu, connection);
                    connection.Open();
                    object maasResult = maasCommand.ExecuteScalar();
                    if (maasResult != DBNull.Value)
                    {
                        toplam += Convert.ToDouble(maasResult);
                    }
                }

                // Toplam değeri Label kontrolüne yazdır
                label21.Text = toplam.ToString("N0") + " ₺"; //
            }
            catch (Exception ex)
            {
                MessageBox.Show("Toplam miktar alınırken bir hata oluştu: " + ex.Message);
            }


            try
            {
                // Label6'daki değeri alıp double türüne dönüştür
                double label6Deger = Convert.ToDouble(label6.Text.Replace("Ortalama Miktar: ", "").Replace(" ₺", ""));

                // Label21'deki değeri alıp double türüne dönüştür
                double label21Deger = Convert.ToDouble(label21.Text.Replace("Toplam: ", "").Replace(" ₺", ""));

                // Label21'deki değeri Label6'daki değerden çıkar
                double sonuc = label6Deger - label21Deger;

                // Sonucu Label25'e yazdır
                label25.Text = sonuc.ToString("N2") + " ₺"; // N2 formatı 2 ondalık basamağa kadar gösterir
                if (sonuc > 0)
                {
                    panel13.BackColor = Color.Green;
                }
                else
                {
                    panel13.BackColor = Color.Crimson;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("İşlem gerçekleştirilirken bir hata oluştu: " + ex.Message);
            }
        }

        private void raporlar9_Load(object sender, EventArgs e)
        {
            VeriSayisiniYazdir();
        }
    }
}
