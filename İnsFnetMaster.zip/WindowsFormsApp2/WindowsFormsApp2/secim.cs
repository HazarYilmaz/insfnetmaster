﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.SqlServer.Server;
using WindowsFormsApp2.menu;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp2
{
    public partial class secim : Form
    {
        
        string connectionString = @"Data Source=.;Initial Catalog=gnc;Integrated Security=True;TrustServerCertificate=true";
        public secim()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // TextBox'tan yeni inşaat adını al
            string yeniInsaatAdi = textBox1.Text.Trim();

            // Eğer TextBox boşsa, işlem yapma
            if (string.IsNullOrEmpty(yeniInsaatAdi))
            {
                MessageBox.Show("Lütfen bir inşaat adı girin.");
                return;
            }

            // SqlConnection nesnesi oluşturma
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    // Veritabanı bağlantısını açma
                    connection.Open();

                    // Aynı inşaat adının var olup olmadığını kontrol et
                    string checkQuery = "SELECT COUNT(*) FROM insaat_isim WHERE insaat_adi = @InsaatAdi";
                    using (SqlCommand checkCommand = new SqlCommand(checkQuery, connection))
                    {
                        checkCommand.Parameters.AddWithValue("@InsaatAdi", yeniInsaatAdi);
                        int existingCount = Convert.ToInt32(checkCommand.ExecuteScalar());
                        if (existingCount > 0)
                        {
                            button1.Visible = false;
                            textBox1.Visible = false;
                            label4.Visible = false;
                            label2.Visible = false;
                            label1.Visible = true;
                            button2.Visible = true;
                            MessageBox.Show("Bu inşaat adı zaten mevcut.");
                            return; // İşlemi iptal et

                        }
                    }

                    // Seçili olan inşaat adını al
                    string secilenInsaatAdi = comboBox1.SelectedItem.ToString();

                    // SQL sorgusu oluşturma
                    string query = "UPDATE insaat_isim SET insaat_adi = @YeniInsaatAdi WHERE insaat_adi = @SecilenInsaatAdi";

                    // SqlCommand oluşturma
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // Parametre ekleyerek SQL sorgusunu güvenli hale getirme
                        command.Parameters.AddWithValue("@YeniInsaatAdi", yeniInsaatAdi);
                        command.Parameters.AddWithValue("@SecilenInsaatAdi", secilenInsaatAdi);

                        // SQL sorgusunu çalıştırma
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("İnşaat adı başarıyla güncellendi!");
                            comboBox1.Items.Clear();
                            textBox1.Clear();
                            // Eğer başarılı bir şekilde güncellendi ise, ComboBox'ı yeniden yükleme
                            LoadDataToComboBox();
                            button1.Visible = false;
                            textBox1.Visible = false;
                            label4.Visible = false;
                            label2.Visible = false;
                            label1.Visible = true;
                            button2.Visible = true;
                        }
                        else
                        {
                            MessageBox.Show("İnşaat adı güncellenirken bir hata oluştu.");
                            button1.Visible = false;
                            textBox1.Visible = false;
                            label4.Visible = false;
                            label2.Visible = false;
                            label1.Visible = true;
                            button2.Visible = true;
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("İnşaat adı güncellenirken bir hata oluştu: " + ex.Message);
                    button1.Visible = false;
                    textBox1.Visible = false;
                    label4.Visible = false;
                    label2.Visible = false;
                    label1.Visible = true;
                    button2.Visible = true;
                }
            }
        }

        private void secim_Load(object sender, EventArgs e)
        {
            ConnectToDatabase();
            LoadDataToComboBox();

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text == "1 (İsim Ekle)" || comboBox1.Text == "2 (İsim Ekle)" || comboBox1.Text == "3 (İsim Ekle)" || comboBox1.Text == "4 (İsim Ekle)" || comboBox1.Text == "5 (İsim Ekle)" || comboBox1.Text == "6 (İsim Ekle)" || comboBox1.Text == "7 (İsim Ekle)" 
                || comboBox1.Text == "8 (İsim Ekle)" || comboBox1.Text == "9 (İsim Ekle)" || comboBox1.Text == "10 (İsim Ekle)" || comboBox1.Text == "11 (İsim Ekle)" || comboBox1.Text == "12 (İsim Ekle)" || comboBox1.Text == "13 (İsim Ekle)" || comboBox1.Text == "14 (İsim Ekle)" 
                || comboBox1.Text == "15 (İsim Ekle)" )
            {
                button1.Visible = true;
                textBox1.Visible = true;
                label4.Visible = true;
                label2.Visible = true;
                label1.Visible = false;
                button2.Visible = false;

            }
            else
            {
                button1.Visible = false;
                textBox1.Visible = false;
                label4.Visible = false;
                label2.Visible = false;
                label1.Visible = true;
                button2.Visible = true;
            }


        }
        private void ConnectToDatabase()
        {
            // SqlConnection nesnesi oluşturma
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    // Veritabanı bağlantısını açma
                    connection.Open();
                   

                    // Bağlantı başarılı olduğunda burada istediğiniz işlemleri gerçekleştirebilirsiniz.

                    // Örneğin, bağlantıyı kapatmak isterseniz:
                    // connection.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanına bağlanırken bir hata oluştu: " + ex.Message);
                }
            }
        }
        private void LoadDataToComboBox()
        {
            // SqlConnection nesnesi oluşturma
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    // Veritabanı bağlantısını açma
                    connection.Open();

                    // SQL sorgusu
                    string query = "SELECT insaat_adi FROM insaat_isim";

                    // SqlCommand oluşturma
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // SqlDataReader oluşturma
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            // ComboBox'a verileri ekleme
                            while (reader.Read())
                            {
                                comboBox1.Items.Add(reader["insaat_adi"].ToString());
                                
                            }
                            
                        }
                    }

                    
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veriler yüklenirken bir hata oluştu: " + ex.Message);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Refresh();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button2_Click_1(object sender, EventArgs e)
        {

            if (comboBox1.SelectedIndex == 0)
            {


                // ComboBox'taki 0. indexin text değerini al
                int selectedtext = comboBox1.SelectedIndex; // Seçilen ComboBox indeksi

                // Form0'i açma
                menu0 form0 = new menu0();
                form0.Show();
                this.Hide();

            }
            else if (comboBox1.SelectedIndex == 1)
            {


                // ComboBox'taki 1. indexin text değerini al
                int selectedtext = comboBox1.SelectedIndex; // Seçilen ComboBox indeksi

                // Form1'i açma
                menu1 form1 = new menu1();
                form1.Show();
                this.Hide();

            }
            else if (comboBox1.SelectedIndex == 2)
            {


                // ComboBox'taki 2. indexin text değerini al
                int selectedtext = comboBox1.SelectedIndex; // Seçilen ComboBox indeksi

                // Form2'i açma
                menu2 form2 = new menu2();
                form2.Show();
                this.Hide();

            }
            else if (comboBox1.SelectedIndex == 3)
            {


                // ComboBox'taki 2. indexin text değerini al
                int selectedtext = comboBox1.SelectedIndex; // Seçilen ComboBox indeksi

                // Form2'i açma
                menu3 form3 = new menu3();
                form3.Show();
                this.Hide();

            }
            else if (comboBox1.SelectedIndex == 4)
            {


                // ComboBox'taki 2. indexin text değerini al
                int selectedtext = comboBox1.SelectedIndex; // Seçilen ComboBox indeksi

                // Form4'i açma
                menu4 form4 = new menu4();
                form4.Show();
                this.Hide();

            }
            else if (comboBox1.SelectedIndex == 5)
            {


                // ComboBox'taki 2. indexin text değerini al
                int selectedtext = comboBox1.SelectedIndex; // Seçilen ComboBox indeksi

                // Form2'i açma
                menu5 form5 = new menu5();
                form5.Show();
                this.Hide();

            }
            else if (comboBox1.SelectedIndex == 6)
            {


                // ComboBox'taki 2. indexin text değerini al
                int selectedtext = comboBox1.SelectedIndex; // Seçilen ComboBox indeksi

                // Form2'i açma
                menu6 form6 = new menu6();
                form6.Show();
                this.Hide();

            }
            else if (comboBox1.SelectedIndex == 7)
            {


                // ComboBox'taki 2. indexin text değerini al
                int selectedtext = comboBox1.SelectedIndex; // Seçilen ComboBox indeksi

                // Form2'i açma
                menu7 form7 = new menu7();
                form7.Show();
                this.Hide();

            }
            else if (comboBox1.SelectedIndex == 8)
            {


                // ComboBox'taki 2. indexin text değerini al
                int selectedtext = comboBox1.SelectedIndex; // Seçilen ComboBox indeksi

                // Form2'i açma
                menu8 form8 = new menu8();
                form8.Show();
                this.Hide();

            }
            else if (comboBox1.SelectedIndex == 9)
            {


                // ComboBox'taki 2. indexin text değerini al
                int selectedtext = comboBox1.SelectedIndex; // Seçilen ComboBox indeksi

                // Form2'i açma
                menu9 form9 = new menu9();
                form9.Show();
                this.Hide();

            }
            else if (comboBox1.SelectedIndex == 10)
            {


                // ComboBox'taki 2. indexin text değerini al
                int selectedtext = comboBox1.SelectedIndex; // Seçilen ComboBox indeksi

                // Form2'i açma
                menu10 form10 = new menu10();
                form10.Show();
                this.Hide();

            }
            else if (comboBox1.SelectedIndex == 11)
            {


                // ComboBox'taki 2. indexin text değerini al
                int selectedtext = comboBox1.SelectedIndex; // Seçilen ComboBox indeksi

                // Form2'i açma
                menu11 form11 = new menu11();
                form11.Show();
                this.Hide();

            }
            else if (comboBox1.SelectedIndex == 12)
            {


                // ComboBox'taki 2. indexin text değerini al
                int selectedtext = comboBox1.SelectedIndex; // Seçilen ComboBox indeksi

                // Form2'i açma
                menu12 form12 = new menu12();
                form12.Show();
                this.Hide();

            }
            else if (comboBox1.SelectedIndex == 13)
            {


                // ComboBox'taki 2. indexin text değerini al
                int selectedtext = comboBox1.SelectedIndex; // Seçilen ComboBox indeksi

                // Form2'i açma
                menu13 form13 = new menu13();
                form13.Show();
                this.Hide();

            }
            else if (comboBox1.SelectedIndex == 14)
            {


                // ComboBox'taki 2. indexin text değerini al
                int selectedtext = comboBox1.SelectedIndex; // Seçilen ComboBox indeksi

                // Form2'i açma
                menu14 form14 = new menu14();
                form14.Show();
                this.Hide();

            }
            else if (comboBox1.SelectedIndex == 15) 
            {

                int selectedtext = comboBox1.SelectedIndex; // Seçilen ComboBox indeksi

                // Form2'yi açma
                menuadmin form15 = new menuadmin();
                form15.Show();
                this.Hide();

            }


        }
    }
}
