﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp2.maas
{
    public partial class apartmanlar : Form
    {
        public apartmanlar()
        {
            InitializeComponent();
        }
        string connectionString = @"Data Source=.;Initial Catalog=gnc;Integrated Security=True;TrustServerCertificate=true";
        private void apartmanlar_Load(object sender, EventArgs e)
        {
            ComboBoxDoldur();
            ResizeDataGridView();
            gizle();
            dataGridView1.ReadOnly = true;
        }
        private void gizle()
        {
            textBox2.Visible = false;
            textBox3.Visible = false;
            label1.Visible = false;
            label2.Visible = false;
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Visible = false;
            textBox4.Text="";
            textBox5.Text = "";
            button1.Visible = false;
            textBox5.Visible = false;
            label6.Visible = false;
            label3.Visible = false;
            button5.Visible = false;
            textBox6.Visible = false;
            textBox6.Text = "";
            label4.Visible = false;
            button7.Visible = false;

        }
        private void ResizeDataGridView()
        {
            // Sütunların otomatik boyutlandırılmasını sağla
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            // Satırların otomatik boyutlandırılmasını sağla
            dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;


        }
        private Dictionary<string, int> idDictionary = new Dictionary<string, int>();
        private void ComboBoxDoldur()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT insaat_adi,id FROM insaat_isim WHERE insaat_adi NOT IN ('1 (İsim Ekle)', '2 (İsim Ekle)', '3 (İsim Ekle)', '4 (İsim Ekle)', '5 (İsim Ekle)', '6 (İsim Ekle)', '7 (İsim Ekle)', '8 (İsim Ekle)', '9 (İsim Ekle)', '10 (İsim Ekle)', '11 (İsim Ekle)', '12 (İsim Ekle)', '13 (İsim Ekle)', '14 (İsim Ekle)', '15 (İsim Ekle)', '16 (İsim Ekle)', 'Admin' )";
                    SqlCommand command = new SqlCommand(query, connection);
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        string insaatAdi = reader["insaat_adi"].ToString();
                        comboBox1.Items.Add(insaatAdi);
                        // ComboBox'a her bir öğe eklenirken, karşılık gelen ID'yi bir dictionary'e ekleyebiliriz
                        int id = Convert.ToInt32(reader["id"]);
                        idDictionary.Add(insaatAdi, id);
                    }
                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
            }

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string secilenInsaatAdi = comboBox1.SelectedItem.ToString();

            // Seçilen inşaat adının ID'sini alıyoruz
            int secilenInsaatId = idDictionary[secilenInsaatAdi];

            // TextBox'a ID'yi yazdırıyoruz
            textBox1.Text = secilenInsaatId.ToString();
            VerileriYukle();
            ResizeDataGridView();
        }
        private void VerileriYukle()
        {
            if (textBox1.Text == "1")
            {


                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Veritabanından belirli sütunları seçerek personel bilgilerini alacak sorguyu oluşturalım
                        string query = "SELECT id as 'İd',apartman_adi AS 'Apartman Adı', daire_no AS 'Daire Numarası', durum AS 'Durum' FROM birapart";
                        SqlCommand command = new SqlCommand(query, connection);

                        // SqlDataAdapter nesnesi oluşturalım ve verileri yükleyelim
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // DataGridView'e verileri yükleyelim
                        dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "2")
            {

                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Veritabanından belirli sütunları seçerek personel bilgilerini alacak sorguyu oluşturalım
                        string query = "SELECT id as 'İd',apartman_adi AS 'Apartman Adı', daire_no AS 'Daire Numarası', durum AS 'Durum' FROM ikiapart";
                        SqlCommand command = new SqlCommand(query, connection);

                        // SqlDataAdapter nesnesi oluşturalım ve verileri yükleyelim
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // DataGridView'e verileri yükleyelim
                        dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "3")
            {

                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Veritabanından belirli sütunları seçerek personel bilgilerini alacak sorguyu oluşturalım
                        string query = "SELECT id as 'İd',apartman_adi AS 'Apartman Adı', daire_no AS 'Daire Numarası', durum AS 'Durum' FROM ucapart";
                        SqlCommand command = new SqlCommand(query, connection);

                        // SqlDataAdapter nesnesi oluşturalım ve verileri yükleyelim
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // DataGridView'e verileri yükleyelim
                        dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "4")
            {

                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Veritabanından belirli sütunları seçerek personel bilgilerini alacak sorguyu oluşturalım
                        string query = "SELECT id as 'İd',apartman_adi AS 'Apartman Adı', daire_no AS 'Daire Numarası', durum AS 'Durum' FROM dortapart";
                        SqlCommand command = new SqlCommand(query, connection);

                        // SqlDataAdapter nesnesi oluşturalım ve verileri yükleyelim
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // DataGridView'e verileri yükleyelim
                        dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "5")
            {

                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Veritabanından belirli sütunları seçerek personel bilgilerini alacak sorguyu oluşturalım
                        string query = "SELECT id as 'İd',apartman_adi AS 'Apartman Adı', daire_no AS 'Daire Numarası', durum AS 'Durum' FROM besapart";
                        SqlCommand command = new SqlCommand(query, connection);

                        // SqlDataAdapter nesnesi oluşturalım ve verileri yükleyelim
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // DataGridView'e verileri yükleyelim
                        dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "6")
            {

                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Veritabanından belirli sütunları seçerek personel bilgilerini alacak sorguyu oluşturalım
                        string query = "SELECT id as 'İd',apartman_adi AS 'Apartman Adı', daire_no AS 'Daire Numarası', durum AS 'Durum' FROM altiapart";
                        SqlCommand command = new SqlCommand(query, connection);

                        // SqlDataAdapter nesnesi oluşturalım ve verileri yükleyelim
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // DataGridView'e verileri yükleyelim
                        dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "7")
            {

                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Veritabanından belirli sütunları seçerek personel bilgilerini alacak sorguyu oluşturalım
                        string query = "SELECT id as 'İd',apartman_adi AS 'Apartman Adı', daire_no AS 'Daire Numarası', durum AS 'Durum' FROM yediapart";
                        SqlCommand command = new SqlCommand(query, connection);

                        // SqlDataAdapter nesnesi oluşturalım ve verileri yükleyelim
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // DataGridView'e verileri yükleyelim
                        dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "8")
            {

                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Veritabanından belirli sütunları seçerek personel bilgilerini alacak sorguyu oluşturalım
                        string query = "SELECT id as 'İd',apartman_adi AS 'Apartman Adı', daire_no AS 'Daire Numarası', durum AS 'Durum' FROM sekizapart";
                        SqlCommand command = new SqlCommand(query, connection);

                        // SqlDataAdapter nesnesi oluşturalım ve verileri yükleyelim
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // DataGridView'e verileri yükleyelim
                        dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "9")
            {

                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Veritabanından belirli sütunları seçerek personel bilgilerini alacak sorguyu oluşturalım
                        string query = "SELECT id as 'İd',apartman_adi AS 'Apartman Adı', daire_no AS 'Daire Numarası', durum AS 'Durum' FROM dokuzapart";
                        SqlCommand command = new SqlCommand(query, connection);

                        // SqlDataAdapter nesnesi oluşturalım ve verileri yükleyelim
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // DataGridView'e verileri yükleyelim
                        dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "10")
            {

                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Veritabanından belirli sütunları seçerek personel bilgilerini alacak sorguyu oluşturalım
                        string query = "SELECT id as 'İd',apartman_adi AS 'Apartman Adı', daire_no AS 'Daire Numarası', durum AS 'Durum' FROM onapart";
                        SqlCommand command = new SqlCommand(query, connection);

                        // SqlDataAdapter nesnesi oluşturalım ve verileri yükleyelim
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // DataGridView'e verileri yükleyelim
                        dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "11")
            {

                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Veritabanından belirli sütunları seçerek personel bilgilerini alacak sorguyu oluşturalım
                        string query = "SELECT id as 'İd',apartman_adi AS 'Apartman Adı', daire_no AS 'Daire Numarası', durum AS 'Durum' FROM onbirapart";
                        SqlCommand command = new SqlCommand(query, connection);

                        // SqlDataAdapter nesnesi oluşturalım ve verileri yükleyelim
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // DataGridView'e verileri yükleyelim
                        dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "12")
            {

                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Veritabanından belirli sütunları seçerek personel bilgilerini alacak sorguyu oluşturalım
                        string query = "SELECT id as 'İd',apartman_adi AS 'Apartman Adı', daire_no AS 'Daire Numarası', durum AS 'Durum' FROM onikiapart";
                        SqlCommand command = new SqlCommand(query, connection);

                        // SqlDataAdapter nesnesi oluşturalım ve verileri yükleyelim
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // DataGridView'e verileri yükleyelim
                        dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "13")
            {

                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Veritabanından belirli sütunları seçerek personel bilgilerini alacak sorguyu oluşturalım
                        string query = "SELECT id as 'İd',apartman_adi AS 'Apartman Adı', daire_no AS 'Daire Numarası', durum AS 'Durum' FROM onucapart";
                        SqlCommand command = new SqlCommand(query, connection);

                        // SqlDataAdapter nesnesi oluşturalım ve verileri yükleyelim
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // DataGridView'e verileri yükleyelim
                        dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "14")
            {

                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Veritabanından belirli sütunları seçerek personel bilgilerini alacak sorguyu oluşturalım
                        string query = "SELECT id as 'İd',apartman_adi AS 'Apartman Adı', daire_no AS 'Daire Numarası', durum AS 'Durum' FROM ondortapart";
                        SqlCommand command = new SqlCommand(query, connection);

                        // SqlDataAdapter nesnesi oluşturalım ve verileri yükleyelim
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // DataGridView'e verileri yükleyelim
                        dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "15")
            {

                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Veritabanından belirli sütunları seçerek personel bilgilerini alacak sorguyu oluşturalım
                        string query = "SELECT id as 'İd',apartman_adi AS 'Apartman Adı', daire_no AS 'Daire Numarası', durum AS 'Durum' FROM onbesapart";
                        SqlCommand command = new SqlCommand(query, connection);

                        // SqlDataAdapter nesnesi oluşturalım ve verileri yükleyelim
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // DataGridView'e verileri yükleyelim
                        dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox2.Text !="" && textBox3.Text!="")
            {


                if (textBox1.Text == "1")
                {

                    try
                    {
                        int deger = Convert.ToInt32(textBox3.Text);
                        for (int i = 1; i < deger + 1; i++)
                        {
                            using (SqlConnection connection = new SqlConnection(connectionString))
                            {
                                // INSERT INTO sorgusunu oluşturalım
                                string query = "INSERT INTO birapart (apartman_adi, daire_no, durum) VALUES (@apartman_adi, @daire_no, @durum)";
                                SqlCommand command = new SqlCommand(query, connection);
                                command.Parameters.AddWithValue("@apartman_adi", textBox2.Text);
                                command.Parameters.AddWithValue("@daire_no", i);
                                command.Parameters.AddWithValue("@durum", "Aktif");

                                // Bağlantıyı açalım ve sorguyu çalıştıralım
                                connection.Open();
                                command.ExecuteNonQuery();
                            }
                        }

                        // for döngüsü bittiğinde ve try bloğu başarılıysa mesaj kutusu göster
                        MessageBox.Show("Tüm daireler başarıyla eklendi.");
                        VerileriYukle();
                        gizle();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Daireler eklenirken bir hata oluştu: " + ex.Message);
                    }

                }
                else if (textBox1.Text == "2")
                {

                    try
                    {
                        int deger = Convert.ToInt32(textBox3.Text);
                        for (int i = 1; i < deger + 1; i++)
                        {
                            using (SqlConnection connection = new SqlConnection(connectionString))
                            {
                                // INSERT INTO sorgusunu oluşturalım
                                string query = "INSERT INTO ikiapart (apartman_adi, daire_no, durum) VALUES (@apartman_adi, @daire_no, @durum)";
                                SqlCommand command = new SqlCommand(query, connection);
                                command.Parameters.AddWithValue("@apartman_adi", textBox2.Text);
                                command.Parameters.AddWithValue("@daire_no", i);
                                command.Parameters.AddWithValue("@durum", "Aktif");

                                // Bağlantıyı açalım ve sorguyu çalıştıralım
                                connection.Open();
                                command.ExecuteNonQuery();
                            }
                        }

                        // for döngüsü bittiğinde ve try bloğu başarılıysa mesaj kutusu göster
                        MessageBox.Show("Tüm daireler başarıyla eklendi.");
                        VerileriYukle();
                        gizle();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Daireler eklenirken bir hata oluştu: " + ex.Message);
                    }

                }
                else if (textBox1.Text == "3")
                {

                    try
                    {
                        int deger = Convert.ToInt32(textBox3.Text);
                        for (int i = 1; i < deger + 1; i++)
                        {
                            using (SqlConnection connection = new SqlConnection(connectionString))
                            {
                                // INSERT INTO sorgusunu oluşturalım
                                string query = "INSERT INTO ucapart (apartman_adi, daire_no, durum) VALUES (@apartman_adi, @daire_no, @durum)";
                                SqlCommand command = new SqlCommand(query, connection);
                                command.Parameters.AddWithValue("@apartman_adi", textBox2.Text);
                                command.Parameters.AddWithValue("@daire_no", i);
                                command.Parameters.AddWithValue("@durum", "Aktif");

                                // Bağlantıyı açalım ve sorguyu çalıştıralım
                                connection.Open();
                                command.ExecuteNonQuery();
                            }
                        }

                        // for döngüsü bittiğinde ve try bloğu başarılıysa mesaj kutusu göster
                        MessageBox.Show("Tüm daireler başarıyla eklendi.");
                        VerileriYukle();
                        gizle();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Daireler eklenirken bir hata oluştu: " + ex.Message);
                    }

                }
                else if (textBox1.Text == "4")
                {

                    try
                    {
                        int deger = Convert.ToInt32(textBox3.Text);
                        for (int i = 1; i < deger + 1; i++)
                        {
                            using (SqlConnection connection = new SqlConnection(connectionString))
                            {
                                // INSERT INTO sorgusunu oluşturalım
                                string query = "INSERT INTO dortapart (apartman_adi, daire_no, durum) VALUES (@apartman_adi, @daire_no, @durum)";
                                SqlCommand command = new SqlCommand(query, connection);
                                command.Parameters.AddWithValue("@apartman_adi", textBox2.Text);
                                command.Parameters.AddWithValue("@daire_no", i);
                                command.Parameters.AddWithValue("@durum", "Aktif");

                                // Bağlantıyı açalım ve sorguyu çalıştıralım
                                connection.Open();
                                command.ExecuteNonQuery();
                            }
                        }

                        // for döngüsü bittiğinde ve try bloğu başarılıysa mesaj kutusu göster
                        MessageBox.Show("Tüm daireler başarıyla eklendi.");
                        VerileriYukle();
                        gizle();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Daireler eklenirken bir hata oluştu: " + ex.Message);
                    }

                }
                else if (textBox1.Text == "5")
                {

                    try
                    {
                        int deger = Convert.ToInt32(textBox3.Text);
                        for (int i = 1; i < deger + 1; i++)
                        {
                            using (SqlConnection connection = new SqlConnection(connectionString))
                            {
                                // INSERT INTO sorgusunu oluşturalım
                                string query = "INSERT INTO besapart (apartman_adi, daire_no, durum) VALUES (@apartman_adi, @daire_no, @durum)";
                                SqlCommand command = new SqlCommand(query, connection);
                                command.Parameters.AddWithValue("@apartman_adi", textBox2.Text);
                                command.Parameters.AddWithValue("@daire_no", i);
                                command.Parameters.AddWithValue("@durum", "Aktif");

                                // Bağlantıyı açalım ve sorguyu çalıştıralım
                                connection.Open();
                                command.ExecuteNonQuery();
                            }
                        }

                        // for döngüsü bittiğinde ve try bloğu başarılıysa mesaj kutusu göster
                        MessageBox.Show("Tüm daireler başarıyla eklendi.");
                        VerileriYukle();
                        gizle();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Daireler eklenirken bir hata oluştu: " + ex.Message);
                    }

                }
                else if (textBox1.Text == "6")
                {

                    try
                    {
                        int deger = Convert.ToInt32(textBox3.Text);
                        for (int i = 1; i < deger + 1; i++)
                        {
                            using (SqlConnection connection = new SqlConnection(connectionString))
                            {
                                // INSERT INTO sorgusunu oluşturalım
                                string query = "INSERT INTO altiapart (apartman_adi, daire_no, durum) VALUES (@apartman_adi, @daire_no, @durum)";
                                SqlCommand command = new SqlCommand(query, connection);
                                command.Parameters.AddWithValue("@apartman_adi", textBox2.Text);
                                command.Parameters.AddWithValue("@daire_no", i);
                                command.Parameters.AddWithValue("@durum", "Aktif");

                                // Bağlantıyı açalım ve sorguyu çalıştıralım
                                connection.Open();
                                command.ExecuteNonQuery();
                            }
                        }

                        // for döngüsü bittiğinde ve try bloğu başarılıysa mesaj kutusu göster
                        MessageBox.Show("Tüm daireler başarıyla eklendi.");
                        VerileriYukle();
                        gizle();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Daireler eklenirken bir hata oluştu: " + ex.Message);
                    }

                }
                else if (textBox1.Text == "7")
                {

                    try
                    {
                        int deger = Convert.ToInt32(textBox3.Text);
                        for (int i = 1; i < deger + 1; i++)
                        {
                            using (SqlConnection connection = new SqlConnection(connectionString))
                            {
                                // INSERT INTO sorgusunu oluşturalım
                                string query = "INSERT INTO yediapart (apartman_adi, daire_no, durum) VALUES (@apartman_adi, @daire_no, @durum)";
                                SqlCommand command = new SqlCommand(query, connection);
                                command.Parameters.AddWithValue("@apartman_adi", textBox2.Text);
                                command.Parameters.AddWithValue("@daire_no", i);
                                command.Parameters.AddWithValue("@durum", "Aktif");

                                // Bağlantıyı açalım ve sorguyu çalıştıralım
                                connection.Open();
                                command.ExecuteNonQuery();
                            }
                        }

                        // for döngüsü bittiğinde ve try bloğu başarılıysa mesaj kutusu göster
                        MessageBox.Show("Tüm daireler başarıyla eklendi.");
                        VerileriYukle();
                        gizle();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Daireler eklenirken bir hata oluştu: " + ex.Message);
                    }

                }
                else if (textBox1.Text == "8")
                {

                    try
                    {
                        int deger = Convert.ToInt32(textBox3.Text);
                        for (int i = 1; i < deger + 1; i++)
                        {
                            using (SqlConnection connection = new SqlConnection(connectionString))
                            {
                                // INSERT INTO sorgusunu oluşturalım
                                string query = "INSERT INTO sekizapart (apartman_adi, daire_no, durum) VALUES (@apartman_adi, @daire_no, @durum)";
                                SqlCommand command = new SqlCommand(query, connection);
                                command.Parameters.AddWithValue("@apartman_adi", textBox2.Text);
                                command.Parameters.AddWithValue("@daire_no", i);
                                command.Parameters.AddWithValue("@durum", "Aktif");

                                // Bağlantıyı açalım ve sorguyu çalıştıralım
                                connection.Open();
                                command.ExecuteNonQuery();
                            }
                        }

                        // for döngüsü bittiğinde ve try bloğu başarılıysa mesaj kutusu göster
                        MessageBox.Show("Tüm daireler başarıyla eklendi.");
                        VerileriYukle();
                        gizle();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Daireler eklenirken bir hata oluştu: " + ex.Message);
                    }

                }
                else if (textBox1.Text == "9")
                {

                    try
                    {
                        int deger = Convert.ToInt32(textBox3.Text);
                        for (int i = 1; i < deger + 1; i++)
                        {
                            using (SqlConnection connection = new SqlConnection(connectionString))
                            {
                                // INSERT INTO sorgusunu oluşturalım
                                string query = "INSERT INTO dokuzapart (apartman_adi, daire_no, durum) VALUES (@apartman_adi, @daire_no, @durum)";
                                SqlCommand command = new SqlCommand(query, connection);
                                command.Parameters.AddWithValue("@apartman_adi", textBox2.Text);
                                command.Parameters.AddWithValue("@daire_no", i);
                                command.Parameters.AddWithValue("@durum", "Aktif");

                                // Bağlantıyı açalım ve sorguyu çalıştıralım
                                connection.Open();
                                command.ExecuteNonQuery();
                            }
                        }

                        // for döngüsü bittiğinde ve try bloğu başarılıysa mesaj kutusu göster
                        MessageBox.Show("Tüm daireler başarıyla eklendi.");
                        VerileriYukle();
                        gizle();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Daireler eklenirken bir hata oluştu: " + ex.Message);
                    }

                }
                else if (textBox1.Text == "10")
                {

                    try
                    {
                        int deger = Convert.ToInt32(textBox3.Text);
                        for (int i = 1; i < deger + 1; i++)
                        {
                            using (SqlConnection connection = new SqlConnection(connectionString))
                            {
                                // INSERT INTO sorgusunu oluşturalım
                                string query = "INSERT INTO onapart (apartman_adi, daire_no, durum) VALUES (@apartman_adi, @daire_no, @durum)";
                                SqlCommand command = new SqlCommand(query, connection);
                                command.Parameters.AddWithValue("@apartman_adi", textBox2.Text);
                                command.Parameters.AddWithValue("@daire_no", i);
                                command.Parameters.AddWithValue("@durum", "Aktif");

                                // Bağlantıyı açalım ve sorguyu çalıştıralım
                                connection.Open();
                                command.ExecuteNonQuery();
                            }
                        }

                        // for döngüsü bittiğinde ve try bloğu başarılıysa mesaj kutusu göster
                        MessageBox.Show("Tüm daireler başarıyla eklendi.");
                        VerileriYukle();
                        gizle();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Daireler eklenirken bir hata oluştu: " + ex.Message);
                    }

                }
                else if (textBox1.Text == "11")
                {

                    try
                    {
                        int deger = Convert.ToInt32(textBox3.Text);
                        for (int i = 1; i < deger + 1; i++)
                        {
                            using (SqlConnection connection = new SqlConnection(connectionString))
                            {
                                // INSERT INTO sorgusunu oluşturalım
                                string query = "INSERT INTO onbirapart (apartman_adi, daire_no, durum) VALUES (@apartman_adi, @daire_no, @durum)";
                                SqlCommand command = new SqlCommand(query, connection);
                                command.Parameters.AddWithValue("@apartman_adi", textBox2.Text);
                                command.Parameters.AddWithValue("@daire_no", i);
                                command.Parameters.AddWithValue("@durum", "Aktif");

                                // Bağlantıyı açalım ve sorguyu çalıştıralım
                                connection.Open();
                                command.ExecuteNonQuery();
                            }
                        }

                        // for döngüsü bittiğinde ve try bloğu başarılıysa mesaj kutusu göster
                        MessageBox.Show("Tüm daireler başarıyla eklendi.");
                        VerileriYukle();
                        gizle();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Daireler eklenirken bir hata oluştu: " + ex.Message);
                    }

                }
                else if (textBox1.Text == "12")
                {

                    try
                    {
                        int deger = Convert.ToInt32(textBox3.Text);
                        for (int i = 1; i < deger + 1; i++)
                        {
                            using (SqlConnection connection = new SqlConnection(connectionString))
                            {
                                // INSERT INTO sorgusunu oluşturalım
                                string query = "INSERT INTO onikiapart (apartman_adi, daire_no, durum) VALUES (@apartman_adi, @daire_no, @durum)";
                                SqlCommand command = new SqlCommand(query, connection);
                                command.Parameters.AddWithValue("@apartman_adi", textBox2.Text);
                                command.Parameters.AddWithValue("@daire_no", i);
                                command.Parameters.AddWithValue("@durum", "Aktif");

                                // Bağlantıyı açalım ve sorguyu çalıştıralım
                                connection.Open();
                                command.ExecuteNonQuery();
                            }
                        }

                        // for döngüsü bittiğinde ve try bloğu başarılıysa mesaj kutusu göster
                        MessageBox.Show("Tüm daireler başarıyla eklendi.");
                        VerileriYukle();
                        gizle();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Daireler eklenirken bir hata oluştu: " + ex.Message);
                    }

                }
                else if (textBox1.Text == "13")
                {

                    try
                    {
                        int deger = Convert.ToInt32(textBox3.Text);
                        for (int i = 1; i < deger + 1; i++)
                        {
                            using (SqlConnection connection = new SqlConnection(connectionString))
                            {
                                // INSERT INTO sorgusunu oluşturalım
                                string query = "INSERT INTO onucapart (apartman_adi, daire_no, durum) VALUES (@apartman_adi, @daire_no, @durum)";
                                SqlCommand command = new SqlCommand(query, connection);
                                command.Parameters.AddWithValue("@apartman_adi", textBox2.Text);
                                command.Parameters.AddWithValue("@daire_no", i);
                                command.Parameters.AddWithValue("@durum", "Aktif");

                                // Bağlantıyı açalım ve sorguyu çalıştıralım
                                connection.Open();
                                command.ExecuteNonQuery();
                            }
                        }

                        // for döngüsü bittiğinde ve try bloğu başarılıysa mesaj kutusu göster
                        MessageBox.Show("Tüm daireler başarıyla eklendi.");
                        VerileriYukle();
                        gizle();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Daireler eklenirken bir hata oluştu: " + ex.Message);
                    }

                }
                else if (textBox1.Text == "14")
                {

                    try
                    {
                        int deger = Convert.ToInt32(textBox3.Text);
                        for (int i = 1; i < deger + 1; i++)
                        {
                            using (SqlConnection connection = new SqlConnection(connectionString))
                            {
                                // INSERT INTO sorgusunu oluşturalım
                                string query = "INSERT INTO ondortapart (apartman_adi, daire_no, durum) VALUES (@apartman_adi, @daire_no, @durum)";
                                SqlCommand command = new SqlCommand(query, connection);
                                command.Parameters.AddWithValue("@apartman_adi", textBox2.Text);
                                command.Parameters.AddWithValue("@daire_no", i);
                                command.Parameters.AddWithValue("@durum", "Aktif");

                                // Bağlantıyı açalım ve sorguyu çalıştıralım
                                connection.Open();
                                command.ExecuteNonQuery();
                            }
                        }

                        // for döngüsü bittiğinde ve try bloğu başarılıysa mesaj kutusu göster
                        MessageBox.Show("Tüm daireler başarıyla eklendi.");
                        VerileriYukle();
                        gizle();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Daireler eklenirken bir hata oluştu: " + ex.Message);
                    }
                
                

            }
            else if (textBox1.Text == "15")
            {

                try
                {
                    int deger = Convert.ToInt32(textBox3.Text);
                    for (int i = 1; i < deger + 1; i++)
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // INSERT INTO sorgusunu oluşturalım
                            string query = "INSERT INTO onbesapart (apartman_adi, daire_no, durum) VALUES (@apartman_adi, @daire_no, @durum)";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@apartman_adi", textBox2.Text);
                            command.Parameters.AddWithValue("@daire_no", i);
                            command.Parameters.AddWithValue("@durum", "Aktif");

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();
                        }
                    }

                    // for döngüsü bittiğinde ve try bloğu başarılıysa mesaj kutusu göster
                    MessageBox.Show("Tüm daireler başarıyla eklendi.");
                    VerileriYukle();
                    gizle();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Daireler eklenirken bir hata oluştu: " + ex.Message);
                }

            }
            }
            else
            {
                MessageBox.Show("Lütfen Tüm Alanları Doldurunuz");
            }


        }

        private void button4_Click(object sender, EventArgs e)
        {
            gizle();
            textBox2.Visible = true;
            textBox3.Visible = true;
            label1.Visible = true;
            label2.Visible = true;
            button1.Visible = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            gizle();
            textBox4.Visible = true;
            label3.Visible = true;
            button5.Visible = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            gizle();
            label6.Visible = true;
            textBox5.Visible = true;
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            string searchText = textBox5.Text;

            // Arama fonksiyonunu çağır
            SearchAndHighlight(searchText);
        }
        private void SearchAndHighlight(string searchText)
        {
            // DataGridView'i dolaşarak arama yapma
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                // Her bir hücreyi kontrol etme
                foreach (DataGridViewCell cell in row.Cells)
                {
                    // Hücrede aranan metni bulma
                    if (cell.Value != null && cell.Value.ToString().IndexOf(searchText, StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        // Eğer aranan metin bulunduysa, hücreyi ve ilgili sütunu gösterme
                        dataGridView1.CurrentCell = cell;
                        dataGridView1.FirstDisplayedScrollingRowIndex = row.Index;
                        dataGridView1.Columns[cell.ColumnIndex].Visible = true;

                        // Hücreyi seçme
                        dataGridView1.Rows[cell.RowIndex].Selected = true;

                        // Aramayı sonlandır
                        return;
                    }
                }
            }

            // Eğer aranan metin bulunamazsa, kullanıcıya bilgi ver
            MessageBox.Show("Aranan metin bulunamadı.");
            gizle();
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if(textBox4.Text!="")
            {

            
            if (textBox1.Text == "1")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // DELETE FROM sorgusunu oluşturalım
                        string query = "DELETE FROM birapart WHERE id = @ID";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                        // Bağlantıyı açalım ve sorguyu çalıştıralım
                        connection.Open();
                        command.ExecuteNonQuery();

                        VerileriYukle();
                        gizle();
                        // Başarılı bir şekilde silindiğinde kullanıcıyı bilgilendir
                        MessageBox.Show("Öğe başarıyla silindi.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Öğe silinirken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "2")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // DELETE FROM sorgusunu oluşturalım
                        string query = "DELETE FROM ikiapart WHERE id = @ID";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                        // Bağlantıyı açalım ve sorguyu çalıştıralım
                        connection.Open();
                        command.ExecuteNonQuery();

                        VerileriYukle();
                        gizle();
                        // Başarılı bir şekilde silindiğinde kullanıcıyı bilgilendir
                        MessageBox.Show("Öğe başarıyla silindi.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Öğe silinirken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "3")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // DELETE FROM sorgusunu oluşturalım
                        string query = "DELETE FROM ucapart WHERE id = @ID";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                        // Bağlantıyı açalım ve sorguyu çalıştıralım
                        connection.Open();
                        command.ExecuteNonQuery();

                        VerileriYukle();
                        gizle();
                        // Başarılı bir şekilde silindiğinde kullanıcıyı bilgilendir
                        MessageBox.Show("Öğe başarıyla silindi.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Öğe silinirken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "4")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // DELETE FROM sorgusunu oluşturalım
                        string query = "DELETE FROM dortapart WHERE id = @ID";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                        // Bağlantıyı açalım ve sorguyu çalıştıralım
                        connection.Open();
                        command.ExecuteNonQuery();

                        VerileriYukle();
                        gizle();
                        // Başarılı bir şekilde silindiğinde kullanıcıyı bilgilendir
                        MessageBox.Show("Öğe başarıyla silindi.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Öğe silinirken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "5")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // DELETE FROM sorgusunu oluşturalım
                        string query = "DELETE FROM besapart WHERE id = @ID";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                        // Bağlantıyı açalım ve sorguyu çalıştıralım
                        connection.Open();
                        command.ExecuteNonQuery();

                        VerileriYukle();
                        gizle();
                        // Başarılı bir şekilde silindiğinde kullanıcıyı bilgilendir
                        MessageBox.Show("Öğe başarıyla silindi.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Öğe silinirken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "6")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // DELETE FROM sorgusunu oluşturalım
                        string query = "DELETE FROM altiapart WHERE id = @ID";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                        // Bağlantıyı açalım ve sorguyu çalıştıralım
                        connection.Open();
                        command.ExecuteNonQuery();

                        VerileriYukle();
                        gizle();
                        // Başarılı bir şekilde silindiğinde kullanıcıyı bilgilendir
                        MessageBox.Show("Öğe başarıyla silindi.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Öğe silinirken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "7")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // DELETE FROM sorgusunu oluşturalım
                        string query = "DELETE FROM yediapart WHERE id = @ID";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                        // Bağlantıyı açalım ve sorguyu çalıştıralım
                        connection.Open();
                        command.ExecuteNonQuery();

                        VerileriYukle();
                        gizle();
                        // Başarılı bir şekilde silindiğinde kullanıcıyı bilgilendir
                        MessageBox.Show("Öğe başarıyla silindi.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Öğe silinirken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "8")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // DELETE FROM sorgusunu oluşturalım
                        string query = "DELETE FROM sekizapart WHERE id = @ID";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                        // Bağlantıyı açalım ve sorguyu çalıştıralım
                        connection.Open();
                        command.ExecuteNonQuery();

                        VerileriYukle();
                        gizle();
                        // Başarılı bir şekilde silindiğinde kullanıcıyı bilgilendir
                        MessageBox.Show("Öğe başarıyla silindi.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Öğe silinirken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "9")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // DELETE FROM sorgusunu oluşturalım
                        string query = "DELETE FROM dokuzapart WHERE id = @ID";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                        // Bağlantıyı açalım ve sorguyu çalıştıralım
                        connection.Open();
                        command.ExecuteNonQuery();

                        VerileriYukle();
                        gizle();
                        // Başarılı bir şekilde silindiğinde kullanıcıyı bilgilendir
                        MessageBox.Show("Öğe başarıyla silindi.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Öğe silinirken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "10")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // DELETE FROM sorgusunu oluşturalım
                        string query = "DELETE FROM onapart WHERE id = @ID";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                        // Bağlantıyı açalım ve sorguyu çalıştıralım
                        connection.Open();
                        command.ExecuteNonQuery();

                        VerileriYukle();
                        gizle();
                        // Başarılı bir şekilde silindiğinde kullanıcıyı bilgilendir
                        MessageBox.Show("Öğe başarıyla silindi.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Öğe silinirken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "11")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // DELETE FROM sorgusunu oluşturalım
                        string query = "DELETE FROM onbirapart WHERE id = @ID";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                        // Bağlantıyı açalım ve sorguyu çalıştıralım
                        connection.Open();
                        command.ExecuteNonQuery();

                        VerileriYukle();
                        gizle();
                        // Başarılı bir şekilde silindiğinde kullanıcıyı bilgilendir
                        MessageBox.Show("Öğe başarıyla silindi.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Öğe silinirken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "12")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // DELETE FROM sorgusunu oluşturalım
                        string query = "DELETE FROM onikiapart WHERE id = @ID";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                        // Bağlantıyı açalım ve sorguyu çalıştıralım
                        connection.Open();
                        command.ExecuteNonQuery();

                        VerileriYukle();
                        gizle();
                        // Başarılı bir şekilde silindiğinde kullanıcıyı bilgilendir
                        MessageBox.Show("Öğe başarıyla silindi.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Öğe silinirken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "13")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // DELETE FROM sorgusunu oluşturalım
                        string query = "DELETE FROM onucapart WHERE id = @ID";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                        // Bağlantıyı açalım ve sorguyu çalıştıralım
                        connection.Open();
                        command.ExecuteNonQuery();

                        VerileriYukle();
                        gizle();
                        // Başarılı bir şekilde silindiğinde kullanıcıyı bilgilendir
                        MessageBox.Show("Öğe başarıyla silindi.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Öğe silinirken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "14")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // DELETE FROM sorgusunu oluşturalım
                        string query = "DELETE FROM ondortapart WHERE id = @ID";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                        // Bağlantıyı açalım ve sorguyu çalıştıralım
                        connection.Open();
                        command.ExecuteNonQuery();

                        VerileriYukle();
                        gizle();
                        // Başarılı bir şekilde silindiğinde kullanıcıyı bilgilendir
                        MessageBox.Show("Öğe başarıyla silindi.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Öğe silinirken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "15")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // DELETE FROM sorgusunu oluşturalım
                        string query = "DELETE FROM onbesapart WHERE id = @ID";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                        // Bağlantıyı açalım ve sorguyu çalıştıralım
                        connection.Open();
                        command.ExecuteNonQuery();

                        VerileriYukle();
                        gizle();
                        // Başarılı bir şekilde silindiğinde kullanıcıyı bilgilendir
                        MessageBox.Show("Öğe başarıyla silindi.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Öğe silinirken bir hata oluştu: " + ex.Message);
                }
            }
            }
            else
            {
                MessageBox.Show("Lütfen Tüm Alanları Doldurunuz ");
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            gizle();
            textBox6.Visible = true;
            label4.Visible = true;
            button7.Visible = true;
        }

        private void textBox6_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {

            if (textBox6.Text != "")
            {


                if (textBox1.Text == "1")
                {
                    try
                    {
                        // TextBox6'dan gelen ID'ye göre durumu değiştirelim
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // Durumu güncelleme sorgusunu oluşturalım
                            string query = "UPDATE birapart SET durum = CASE WHEN durum = 'Aktif' THEN 'Pasif' ELSE 'Aktif' END WHERE id = @ID";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox6.Text));

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            VerileriYukle();
                            gizle();
                            // Başarılı bir şekilde güncellendiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Durum başarıyla güncellendi.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Durum güncellenirken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "2")
                {
                    try
                    {
                        // TextBox6'dan gelen ID'ye göre durumu değiştirelim
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // Durumu güncelleme sorgusunu oluşturalım
                            string query = "UPDATE ikiapart SET durum = CASE WHEN durum = 'Aktif' THEN 'Pasif' ELSE 'Aktif' END WHERE id = @ID";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox6.Text));

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            VerileriYukle();
                            gizle();
                            // Başarılı bir şekilde güncellendiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Durum başarıyla güncellendi.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Durum güncellenirken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "3")
                {
                    try
                    {
                        // TextBox6'dan gelen ID'ye göre durumu değiştirelim
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // Durumu güncelleme sorgusunu oluşturalım
                            string query = "UPDATE ucapart SET durum = CASE WHEN durum = 'Aktif' THEN 'Pasif' ELSE 'Aktif' END WHERE id = @ID";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox6.Text));

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            VerileriYukle();
                            gizle();
                            // Başarılı bir şekilde güncellendiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Durum başarıyla güncellendi.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Durum güncellenirken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "4")
                {
                    try
                    {
                        // TextBox6'dan gelen ID'ye göre durumu değiştirelim
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // Durumu güncelleme sorgusunu oluşturalım
                            string query = "UPDATE dortapart SET durum = CASE WHEN durum = 'Aktif' THEN 'Pasif' ELSE 'Aktif' END WHERE id = @ID";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox6.Text));

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            VerileriYukle();
                            gizle();
                            // Başarılı bir şekilde güncellendiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Durum başarıyla güncellendi.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Durum güncellenirken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "5")
                {
                    try
                    {
                        // TextBox6'dan gelen ID'ye göre durumu değiştirelim
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // Durumu güncelleme sorgusunu oluşturalım
                            string query = "UPDATE besapart SET durum = CASE WHEN durum = 'Aktif' THEN 'Pasif' ELSE 'Aktif' END WHERE id = @ID";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox6.Text));

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            VerileriYukle();
                            gizle();
                            // Başarılı bir şekilde güncellendiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Durum başarıyla güncellendi.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Durum güncellenirken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "6")
                {
                    try
                    {
                        // TextBox6'dan gelen ID'ye göre durumu değiştirelim
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // Durumu güncelleme sorgusunu oluşturalım
                            string query = "UPDATE altiapart SET durum = CASE WHEN durum = 'Aktif' THEN 'Pasif' ELSE 'Aktif' END WHERE id = @ID";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox6.Text));

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            VerileriYukle();
                            gizle();
                            // Başarılı bir şekilde güncellendiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Durum başarıyla güncellendi.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Durum güncellenirken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "7")
                {
                    try
                    {
                        // TextBox6'dan gelen ID'ye göre durumu değiştirelim
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // Durumu güncelleme sorgusunu oluşturalım
                            string query = "UPDATE yediapart SET durum = CASE WHEN durum = 'Aktif' THEN 'Pasif' ELSE 'Aktif' END WHERE id = @ID";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox6.Text));

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            VerileriYukle();
                            gizle();
                            // Başarılı bir şekilde güncellendiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Durum başarıyla güncellendi.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Durum güncellenirken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "8")
                {
                    try
                    {
                        // TextBox6'dan gelen ID'ye göre durumu değiştirelim
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // Durumu güncelleme sorgusunu oluşturalım
                            string query = "UPDATE sekizapart SET durum = CASE WHEN durum = 'Aktif' THEN 'Pasif' ELSE 'Aktif' END WHERE id = @ID";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox6.Text));

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            VerileriYukle();
                            gizle();
                            // Başarılı bir şekilde güncellendiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Durum başarıyla güncellendi.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Durum güncellenirken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "9")
                {
                    try
                    {
                        // TextBox6'dan gelen ID'ye göre durumu değiştirelim
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // Durumu güncelleme sorgusunu oluşturalım
                            string query = "UPDATE dokuzapart SET durum = CASE WHEN durum = 'Aktif' THEN 'Pasif' ELSE 'Aktif' END WHERE id = @ID";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox6.Text));

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            VerileriYukle();
                            gizle();
                            // Başarılı bir şekilde güncellendiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Durum başarıyla güncellendi.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Durum güncellenirken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "10")
                {
                    try
                    {
                        // TextBox6'dan gelen ID'ye göre durumu değiştirelim
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // Durumu güncelleme sorgusunu oluşturalım
                            string query = "UPDATE onapart SET durum = CASE WHEN durum = 'Aktif' THEN 'Pasif' ELSE 'Aktif' END WHERE id = @ID";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox6.Text));

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            VerileriYukle();
                            gizle();
                            // Başarılı bir şekilde güncellendiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Durum başarıyla güncellendi.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Durum güncellenirken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "11")
                {
                    try
                    {
                        // TextBox6'dan gelen ID'ye göre durumu değiştirelim
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // Durumu güncelleme sorgusunu oluşturalım
                            string query = "UPDATE onbirapart SET durum = CASE WHEN durum = 'Aktif' THEN 'Pasif' ELSE 'Aktif' END WHERE id = @ID";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox6.Text));

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            VerileriYukle();
                            gizle();
                            // Başarılı bir şekilde güncellendiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Durum başarıyla güncellendi.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Durum güncellenirken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "12")
                {
                    try
                    {
                        // TextBox6'dan gelen ID'ye göre durumu değiştirelim
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // Durumu güncelleme sorgusunu oluşturalım
                            string query = "UPDATE onikiapart SET durum = CASE WHEN durum = 'Aktif' THEN 'Pasif' ELSE 'Aktif' END WHERE id = @ID";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox6.Text));

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            VerileriYukle();
                            gizle();
                            // Başarılı bir şekilde güncellendiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Durum başarıyla güncellendi.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Durum güncellenirken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "13")
                {
                    try
                    {
                        // TextBox6'dan gelen ID'ye göre durumu değiştirelim
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // Durumu güncelleme sorgusunu oluşturalım
                            string query = "UPDATE onucapart SET durum = CASE WHEN durum = 'Aktif' THEN 'Pasif' ELSE 'Aktif' END WHERE id = @ID";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox6.Text));

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            VerileriYukle();
                            gizle();
                            // Başarılı bir şekilde güncellendiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Durum başarıyla güncellendi.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Durum güncellenirken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "14")
                {
                    try
                    {
                        // TextBox6'dan gelen ID'ye göre durumu değiştirelim
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // Durumu güncelleme sorgusunu oluşturalım
                            string query = "UPDATE ondortapart SET durum = CASE WHEN durum = 'Aktif' THEN 'Pasif' ELSE 'Aktif' END WHERE id = @ID";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox6.Text));

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            VerileriYukle();
                            gizle();
                            // Başarılı bir şekilde güncellendiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Durum başarıyla güncellendi.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Durum güncellenirken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "15")
                {
                    try
                    {
                        // TextBox6'dan gelen ID'ye göre durumu değiştirelim
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // Durumu güncelleme sorgusunu oluşturalım
                            string query = "UPDATE onbesapart SET durum = CASE WHEN durum = 'Aktif' THEN 'Pasif' ELSE 'Aktif' END WHERE id = @ID";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox6.Text));

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            VerileriYukle();
                            gizle();
                            // Başarılı bir şekilde güncellendiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Durum başarıyla güncellendi.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Durum güncellenirken bir hata oluştu: " + ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("Lütfen Tüm Alanları Doldurunuz.");
            }
        }

        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            // Sadece "durum" sütununda işlem yapalım
            if (dataGridView1.Columns[e.ColumnIndex].Name == "Durum" && e.Value != null)
            {
                string durum = e.Value.ToString();

                // Duruma göre hücre rengini belirleyelim
                if (durum == "Aktif")
                {
                    e.CellStyle.BackColor = Color.Green;
                    e.CellStyle.ForeColor = Color.White;
                }
                else if (durum == "Pasif")
                {
                    e.CellStyle.BackColor = Color.Red;
                    e.CellStyle.ForeColor = Color.White;
                }
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            PrintDocument pd = new PrintDocument();
            pd.PrintPage += new PrintPageEventHandler(PrintPage);
            pd.Print();
        }
        private void PrintPage(object sender, PrintPageEventArgs e)
        {
            // Yazdırma için kullanılacak font
            Font font = new Font("Arial", 10);

            // Yazdırılacak metin için kullanılacak koordinatlar
            float x = 20;
            float y = 20;

            // DataGridView'deki her satırı dolaşarak içerikleri yazdırma
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                // DataGridView'deki her hücreyi dolaşarak içerikleri yazdırma
                foreach (DataGridViewCell cell in row.Cells)
                {
                    // Hücrenin içeriğini al ve yazdır
                    string cellValue = Convert.ToString(cell.Value);
                    e.Graphics.DrawString(cellValue, font, Brushes.Black, x, y);

                    // Bir sonraki hücreye geçmek için x koordinatını artır
                    x += cell.Size.Width;

                    // Hücreler arasında bir boşluk bırakmak için x koordinatını artır
                    x += 10; // Örnek bir boşluk bırakıyoruz, isteğinize göre değiştirebilirsiniz
                }

                // Bir sonraki satıra geçmek için y koordinatını artır ve x koordinatını başa al
                y += dataGridView1.Rows[0].Height;
                x = 20;

                // Sayfaya sığdığı sürece bir sonraki satırı yazdırmaya devam et
                if (y + dataGridView1.Rows[0].Height > e.MarginBounds.Bottom)
                {
                    e.HasMorePages = true;
                    return;
                }
            }

            e.HasMorePages = false;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            gizle();
        }
    }
}
