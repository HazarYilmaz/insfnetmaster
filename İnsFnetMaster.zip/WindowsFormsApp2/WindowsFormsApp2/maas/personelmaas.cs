﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp2.maas
{
    public partial class personelmaas : Form
    {
        public personelmaas()
        {
            InitializeComponent();
        }
        string connectionString = @"Data Source=.;Initial Catalog=gnc;Integrated Security=True;TrustServerCertificate=true";
        private void personelmaas_Load(object sender, EventArgs e)
        {
            ComboBoxDoldur();
            ResizeDataGridView();
            gizle();
            dataGridView1.ReadOnly = true;

        }
        private void gizle()
        {
            label1.Visible = false;
            label2.Visible = false;
            textBox2.Visible = false;
            textBox3.Visible = false;
            button1.Visible = false;
            button4.Visible = false;
            label3.Visible = false;
            textBox4.Visible = false;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string secilenInsaatAdi = comboBox1.SelectedItem.ToString();

            // Seçilen inşaat adının ID'sini alıyoruz
            int secilenInsaatId = idDictionary[secilenInsaatAdi];

            // TextBox'a ID'yi yazdırıyoruz
            textBox1.Text = secilenInsaatId.ToString();
            VerileriYukle();
            ResizeDataGridView();
        }
        private void ComboBoxDoldur()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT insaat_adi,id FROM insaat_isim WHERE insaat_adi NOT IN ('1 (İsim Ekle)', '2 (İsim Ekle)', '3 (İsim Ekle)', '4 (İsim Ekle)', '5 (İsim Ekle)', '6 (İsim Ekle)', '7 (İsim Ekle)', '8 (İsim Ekle)', '9 (İsim Ekle)', '10 (İsim Ekle)', '11 (İsim Ekle)', '12 (İsim Ekle)', '13 (İsim Ekle)', '14 (İsim Ekle)', '15 (İsim Ekle)', '16 (İsim Ekle)', 'Admin' )";
                    SqlCommand command = new SqlCommand(query, connection);
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        string insaatAdi = reader["insaat_adi"].ToString();
                        comboBox1.Items.Add(insaatAdi);
                        // ComboBox'a her bir öğe eklenirken, karşılık gelen ID'yi bir dictionary'e ekleyebiliriz
                        int id = Convert.ToInt32(reader["id"]);
                        idDictionary.Add(insaatAdi, id);
                    }
                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
            }

        }
        private Dictionary<string, int> idDictionary = new Dictionary<string, int>();
        private void VerileriYukle()
        {
            if (textBox1.Text == "1")
            {


                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Veritabanından belirli sütunları seçerek personel bilgilerini alacak sorguyu oluşturalım
                        string query = "SELECT id as 'İd',personel_adi AS 'Adı', personel_soyadi AS 'Soyadı', personel_gorevi AS 'Görevi', maas AS 'Maaşı', toplam_maas AS 'Toplam Maaşı' FROM birpersonel";
                        SqlCommand command = new SqlCommand(query, connection);

                        // SqlDataAdapter nesnesi oluşturalım ve verileri yükleyelim
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // DataGridView'e verileri yükleyelim
                        dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "2")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Veritabanından belirli sütunları seçerek personel bilgilerini alacak sorguyu oluşturalım
                        string query = "SELECT id as 'İd',personel_adi AS 'Adı', personel_soyadi AS 'Soyadı', personel_gorevi AS 'Görevi', maas AS 'Maaşı', toplam_maas AS 'Toplam Maaşı' FROM ikipersonel";
                        SqlCommand command = new SqlCommand(query, connection);

                        // SqlDataAdapter nesnesi oluşturalım ve verileri yükleyelim
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // DataGridView'e verileri yükleyelim
                        dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "3")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Veritabanından belirli sütunları seçerek personel bilgilerini alacak sorguyu oluşturalım
                        string query = "SELECT id as 'İd',personel_adi AS 'Adı', personel_soyadi AS 'Soyadı', personel_gorevi AS 'Görevi', maas AS 'Maaşı', toplam_maas AS 'Toplam Maaşı' FROM ucpersonel";
                        SqlCommand command = new SqlCommand(query, connection);

                        // SqlDataAdapter nesnesi oluşturalım ve verileri yükleyelim
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // DataGridView'e verileri yükleyelim
                        dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "4")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Veritabanından belirli sütunları seçerek personel bilgilerini alacak sorguyu oluşturalım
                        string query = "SELECT id as 'İd',personel_adi AS 'Adı', personel_soyadi AS 'Soyadı', personel_gorevi AS 'Görevi', maas AS 'Maaşı', toplam_maas AS 'Toplam Maaşı' FROM dortpersonel";
                        SqlCommand command = new SqlCommand(query, connection);

                        // SqlDataAdapter nesnesi oluşturalım ve verileri yükleyelim
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // DataGridView'e verileri yükleyelim
                        dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "5")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Veritabanından belirli sütunları seçerek personel bilgilerini alacak sorguyu oluşturalım
                        string query = "SELECT id as 'İd',personel_adi AS 'Adı', personel_soyadi AS 'Soyadı', personel_gorevi AS 'Görevi', maas AS 'Maaşı', toplam_maas AS 'Toplam Maaşı' FROM bespersonel";
                        SqlCommand command = new SqlCommand(query, connection);

                        // SqlDataAdapter nesnesi oluşturalım ve verileri yükleyelim
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // DataGridView'e verileri yükleyelim
                        dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "6")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Veritabanından belirli sütunları seçerek personel bilgilerini alacak sorguyu oluşturalım
                        string query = "SELECT id as 'İd',personel_adi AS 'Adı', personel_soyadi AS 'Soyadı', personel_gorevi AS 'Görevi', maas AS 'Maaşı', toplam_maas AS 'Toplam Maaşı' FROM altipersonel";
                        SqlCommand command = new SqlCommand(query, connection);

                        // SqlDataAdapter nesnesi oluşturalım ve verileri yükleyelim
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // DataGridView'e verileri yükleyelim
                        dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "7")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Veritabanından belirli sütunları seçerek personel bilgilerini alacak sorguyu oluşturalım
                        string query = "SELECT id as 'İd',personel_adi AS 'Adı', personel_soyadi AS 'Soyadı', personel_gorevi AS 'Görevi', maas AS 'Maaşı', toplam_maas AS 'Toplam Maaşı' FROM yedipersonel";
                        SqlCommand command = new SqlCommand(query, connection);

                        // SqlDataAdapter nesnesi oluşturalım ve verileri yükleyelim
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // DataGridView'e verileri yükleyelim
                        dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "8")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Veritabanından belirli sütunları seçerek personel bilgilerini alacak sorguyu oluşturalım
                        string query = "SELECT id as 'İd',personel_adi AS 'Adı', personel_soyadi AS 'Soyadı', personel_gorevi AS 'Görevi', maas AS 'Maaşı', toplam_maas AS 'Toplam Maaşı' FROM sekizpersonel";
                        SqlCommand command = new SqlCommand(query, connection);

                        // SqlDataAdapter nesnesi oluşturalım ve verileri yükleyelim
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // DataGridView'e verileri yükleyelim
                        dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "9")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Veritabanından belirli sütunları seçerek personel bilgilerini alacak sorguyu oluşturalım
                        string query = "SELECT id as 'İd',personel_adi AS 'Adı', personel_soyadi AS 'Soyadı', personel_gorevi AS 'Görevi', maas AS 'Maaşı', toplam_maas AS 'Toplam Maaşı' FROM dokuzpersonel";
                        SqlCommand command = new SqlCommand(query, connection);

                        // SqlDataAdapter nesnesi oluşturalım ve verileri yükleyelim
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // DataGridView'e verileri yükleyelim
                        dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "10")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Veritabanından belirli sütunları seçerek personel bilgilerini alacak sorguyu oluşturalım
                        string query = "SELECT id as 'İd',personel_adi AS 'Adı', personel_soyadi AS 'Soyadı', personel_gorevi AS 'Görevi', maas AS 'Maaşı', toplam_maas AS 'Toplam Maaşı' FROM onpersonel";
                        SqlCommand command = new SqlCommand(query, connection);

                        // SqlDataAdapter nesnesi oluşturalım ve verileri yükleyelim
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // DataGridView'e verileri yükleyelim
                        dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "11")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Veritabanından belirli sütunları seçerek personel bilgilerini alacak sorguyu oluşturalım
                        string query = "SELECT id as 'İd',personel_adi AS 'Adı', personel_soyadi AS 'Soyadı', personel_gorevi AS 'Görevi', maas AS 'Maaşı', toplam_maas AS 'Toplam Maaşı' FROM onbirpersonel";
                        SqlCommand command = new SqlCommand(query, connection);

                        // SqlDataAdapter nesnesi oluşturalım ve verileri yükleyelim
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // DataGridView'e verileri yükleyelim
                        dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "12")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Veritabanından belirli sütunları seçerek personel bilgilerini alacak sorguyu oluşturalım
                        string query = "SELECT id as 'İd',personel_adi AS 'Adı', personel_soyadi AS 'Soyadı', personel_gorevi AS 'Görevi', maas AS 'Maaşı', toplam_maas AS 'Toplam Maaşı' FROM onikipersonel";
                        SqlCommand command = new SqlCommand(query, connection);

                        // SqlDataAdapter nesnesi oluşturalım ve verileri yükleyelim
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // DataGridView'e verileri yükleyelim
                        dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "13")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Veritabanından belirli sütunları seçerek personel bilgilerini alacak sorguyu oluşturalım
                        string query = "SELECT id as 'İd',personel_adi AS 'Adı', personel_soyadi AS 'Soyadı', personel_gorevi AS 'Görevi', maas AS 'Maaşı', toplam_maas AS 'Toplam Maaşı' FROM onucpersonel";
                        SqlCommand command = new SqlCommand(query, connection);

                        // SqlDataAdapter nesnesi oluşturalım ve verileri yükleyelim
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // DataGridView'e verileri yükleyelim
                        dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "14")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Veritabanından belirli sütunları seçerek personel bilgilerini alacak sorguyu oluşturalım
                        string query = "SELECT id as 'İd',personel_adi AS 'Adı', personel_soyadi AS 'Soyadı', personel_gorevi AS 'Görevi', maas AS 'Maaşı', toplam_maas AS 'Toplam Maaşı' FROM ondortpersonel";
                        SqlCommand command = new SqlCommand(query, connection);

                        // SqlDataAdapter nesnesi oluşturalım ve verileri yükleyelim
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // DataGridView'e verileri yükleyelim
                        dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "15")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Veritabanından belirli sütunları seçerek personel bilgilerini alacak sorguyu oluşturalım
                        string query = "SELECT id as 'İd',personel_adi AS 'Adı', personel_soyadi AS 'Soyadı', personel_gorevi AS 'Görevi', maas AS 'Maaşı', toplam_maas AS 'Toplam Maaşı' FROM onbespersonel";
                        SqlCommand command = new SqlCommand(query, connection);

                        // SqlDataAdapter nesnesi oluşturalım ve verileri yükleyelim
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // DataGridView'e verileri yükleyelim
                        dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
                }
            }

        }
        private void ResizeDataGridView()
        {
            // Sütunların otomatik boyutlandırılmasını sağla
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            // Satırların otomatik boyutlandırılmasını sağla
            dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;


        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox2.Text != "")
            {


                if (textBox1.Text == "1")
                {
                    try
                    {
                        // TextBox2'deki değeri alalım
                        string eklenenVeri = textBox2.Text;

                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // Güncelleme sorgusunu oluşturalım
                            string query = "UPDATE birpersonel SET maas =@EklenenVeri";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@EklenenVeri", eklenenVeri);

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            // Başarılı bir şekilde güncellendiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Maaşlar başarıyla güncellendi.");

                            //-------------------------------------------------------
                            string query1 = "UPDATE birpersonel SET toplam_maas = toplam_maas + @EklenenMiktar";
                            SqlCommand command1 = new SqlCommand(query1, connection);
                            command1.Parameters.AddWithValue("@EklenenMiktar", Convert.ToInt32(textBox2.Text));


                            command1.ExecuteNonQuery();
                            VerileriYukle();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Maaşları güncellerken bir hata oluştu: " + ex.Message);
                    }
                }

                else if (textBox1.Text == "2")
                {
                    try
                    {
                        // TextBox2'deki değeri alalım
                        string eklenenVeri = textBox2.Text;

                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // Güncelleme sorgusunu oluşturalım
                            string query = "UPDATE ikipersonel SET maas =@EklenenVeri";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@EklenenVeri", eklenenVeri);

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            // Başarılı bir şekilde güncellendiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Maaşlar başarıyla güncellendi.");

                            //-------------------------------------------------------
                            string query1 = "UPDATE ikipersonel SET toplam_maas = toplam_maas + @EklenenMiktar";
                            SqlCommand command1 = new SqlCommand(query1, connection);
                            command1.Parameters.AddWithValue("@EklenenMiktar", Convert.ToInt32(textBox2.Text));


                            command1.ExecuteNonQuery();

                            VerileriYukle();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Maaşları güncellerken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "3")
                {
                    try
                    {
                        // TextBox2'deki değeri alalım
                        string eklenenVeri = textBox2.Text;

                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // Güncelleme sorgusunu oluşturalım
                            string query = "UPDATE ucpersonel SET maas =@EklenenVeri";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@EklenenVeri", eklenenVeri);

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            // Başarılı bir şekilde güncellendiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Maaşlar başarıyla güncellendi.");
                            //-------------------------------------------------------
                            string query1 = "UPDATE ucpersonel SET toplam_maas = toplam_maas + @EklenenMiktar";
                            SqlCommand command1 = new SqlCommand(query1, connection);
                            command1.Parameters.AddWithValue("@EklenenMiktar", Convert.ToInt32(textBox2.Text));


                            command1.ExecuteNonQuery();
                            VerileriYukle();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Maaşları güncellerken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "4")
                {
                    try
                    {
                        // TextBox2'deki değeri alalım
                        string eklenenVeri = textBox2.Text;

                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // Güncelleme sorgusunu oluşturalım
                            string query = "UPDATE dortpersonel SET maas =@EklenenVeri";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@EklenenVeri", eklenenVeri);

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            // Başarılı bir şekilde güncellendiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Maaşlar başarıyla güncellendi.");
                            //-------------------------------------------------------
                            string query1 = "UPDATE dortpersonel SET toplam_maas = toplam_maas + @EklenenMiktar";
                            SqlCommand command1 = new SqlCommand(query1, connection);
                            command1.Parameters.AddWithValue("@EklenenMiktar", Convert.ToInt32(textBox2.Text));


                            command1.ExecuteNonQuery();

                            VerileriYukle();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Maaşları güncellerken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "5")
                {
                    try
                    {
                        // TextBox2'deki değeri alalım
                        string eklenenVeri = textBox2.Text;

                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // Güncelleme sorgusunu oluşturalım
                            string query = "UPDATE bespersonel SET maas =@EklenenVeri";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@EklenenVeri", eklenenVeri);

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            // Başarılı bir şekilde güncellendiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Maaşlar başarıyla güncellendi.");

                            //-------------------------------------------------------
                            string query1 = "UPDATE bespersonel SET toplam_maas = toplam_maas + @EklenenMiktar";
                            SqlCommand command1 = new SqlCommand(query1, connection);
                            command1.Parameters.AddWithValue("@EklenenMiktar", Convert.ToInt32(textBox2.Text));


                            command1.ExecuteNonQuery();

                            VerileriYukle();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Maaşları güncellerken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "6")
                {
                    try
                    {
                        // TextBox2'deki değeri alalım
                        string eklenenVeri = textBox2.Text;

                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // Güncelleme sorgusunu oluşturalım
                            string query = "UPDATE altipersonel SET maas =@EklenenVeri";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@EklenenVeri", eklenenVeri);

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            // Başarılı bir şekilde güncellendiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Maaşlar başarıyla güncellendi.");


                            //-------------------------------------------------------
                            string query1 = "UPDATE altipersonel SET toplam_maas = toplam_maas + @EklenenMiktar";
                            SqlCommand command1 = new SqlCommand(query1, connection);
                            command1.Parameters.AddWithValue("@EklenenMiktar", Convert.ToInt32(textBox2.Text));


                            command1.ExecuteNonQuery();
                            VerileriYukle();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Maaşları güncellerken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "7")
                {
                    try
                    {
                        // TextBox2'deki değeri alalım
                        string eklenenVeri = textBox2.Text;

                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // Güncelleme sorgusunu oluşturalım
                            string query = "UPDATE yedipersonel SET maas =@EklenenVeri";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@EklenenVeri", eklenenVeri);

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            // Başarılı bir şekilde güncellendiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Maaşlar başarıyla güncellendi.");


                            //-------------------------------------------------------
                            string query1 = "UPDATE yedipersonel SET toplam_maas = toplam_maas + @EklenenMiktar";
                            SqlCommand command1 = new SqlCommand(query1, connection);
                            command1.Parameters.AddWithValue("@EklenenMiktar", Convert.ToInt32(textBox2.Text));


                            command1.ExecuteNonQuery();
                            VerileriYukle();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Maaşları güncellerken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "8")
                {
                    try
                    {
                        // TextBox2'deki değeri alalım
                        string eklenenVeri = textBox2.Text;

                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // Güncelleme sorgusunu oluşturalım
                            string query = "UPDATE sekizpersonel SET maas =@EklenenVeri";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@EklenenVeri", eklenenVeri);

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            // Başarılı bir şekilde güncellendiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Maaşlar başarıyla güncellendi.");

                            //-------------------------------------------------------
                            string query1 = "UPDATE sekizpersonel SET toplam_maas = toplam_maas + @EklenenMiktar";
                            SqlCommand command1 = new SqlCommand(query1, connection);
                            command1.Parameters.AddWithValue("@EklenenMiktar", Convert.ToInt32(textBox2.Text));


                            command1.ExecuteNonQuery();

                            VerileriYukle();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Maaşları güncellerken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "9")
                {
                    try
                    {
                        // TextBox2'deki değeri alalım
                        string eklenenVeri = textBox2.Text;

                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // Güncelleme sorgusunu oluşturalım
                            string query = "UPDATE dokuzpersonel SET maas =@EklenenVeri";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@EklenenVeri", eklenenVeri);

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            // Başarılı bir şekilde güncellendiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Maaşlar başarıyla güncellendi.");


                            //-------------------------------------------------------
                            string query1 = "UPDATE dokuzpersonel SET toplam_maas = toplam_maas + @EklenenMiktar";
                            SqlCommand command1 = new SqlCommand(query1, connection);
                            command1.Parameters.AddWithValue("@EklenenMiktar", Convert.ToInt32(textBox2.Text));


                            command1.ExecuteNonQuery();
                            VerileriYukle();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Maaşları güncellerken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "10")
                {
                    try
                    {
                        // TextBox2'deki değeri alalım
                        string eklenenVeri = textBox2.Text;

                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // Güncelleme sorgusunu oluşturalım
                            string query = "UPDATE onpersonel SET maas =@EklenenVeri";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@EklenenVeri", eklenenVeri);

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            // Başarılı bir şekilde güncellendiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Maaşlar başarıyla güncellendi.");

                            //-------------------------------------------------------
                            string query1 = "UPDATE onpersonel SET toplam_maas = toplam_maas + @EklenenMiktar";
                            SqlCommand command1 = new SqlCommand(query1, connection);
                            command1.Parameters.AddWithValue("@EklenenMiktar", Convert.ToInt32(textBox2.Text));


                            command1.ExecuteNonQuery();


                            VerileriYukle();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Maaşları güncellerken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "11")
                {
                    try
                    {
                        // TextBox2'deki değeri alalım
                        string eklenenVeri = textBox2.Text;

                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // Güncelleme sorgusunu oluşturalım
                            string query = "UPDATE onbirpersonel SET maas =@EklenenVeri";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@EklenenVeri", eklenenVeri);

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            // Başarılı bir şekilde güncellendiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Maaşlar başarıyla güncellendi.");

                            //-------------------------------------------------------
                            string query1 = "UPDATE onbirpersonel SET toplam_maas = toplam_maas + @EklenenMiktar";
                            SqlCommand command1 = new SqlCommand(query1, connection);
                            command1.Parameters.AddWithValue("@EklenenMiktar", Convert.ToInt32(textBox2.Text));


                            command1.ExecuteNonQuery();

                            VerileriYukle();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Maaşları güncellerken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "12")
                {
                    try
                    {
                        // TextBox2'deki değeri alalım
                        string eklenenVeri = textBox2.Text;

                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // Güncelleme sorgusunu oluşturalım
                            string query = "UPDATE onikipersonel SET maas =@EklenenVeri";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@EklenenVeri", eklenenVeri);

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            // Başarılı bir şekilde güncellendiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Maaşlar başarıyla güncellendi.");

                            //-------------------------------------------------------
                            string query1 = "UPDATE onikipersonel SET toplam_maas = toplam_maas + @EklenenMiktar";
                            SqlCommand command1 = new SqlCommand(query1, connection);
                            command1.Parameters.AddWithValue("@EklenenMiktar", Convert.ToInt32(textBox2.Text));


                            command1.ExecuteNonQuery();

                            VerileriYukle();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Maaşları güncellerken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "13")
                {
                    try
                    {
                        // TextBox2'deki değeri alalım
                        string eklenenVeri = textBox2.Text;

                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // Güncelleme sorgusunu oluşturalım
                            string query = "UPDATE onucpersonel SET maas =@EklenenVeri";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@EklenenVeri", eklenenVeri);

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            // Başarılı bir şekilde güncellendiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Maaşlar başarıyla güncellendi.");

                            //-------------------------------------------------------
                            string query1 = "UPDATE onucpersonel SET toplam_maas = toplam_maas + @EklenenMiktar";
                            SqlCommand command1 = new SqlCommand(query1, connection);
                            command1.Parameters.AddWithValue("@EklenenMiktar", Convert.ToInt32(textBox2.Text));


                            command1.ExecuteNonQuery();

                            VerileriYukle();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Maaşları güncellerken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "14")
                {
                    try
                    {
                        // TextBox2'deki değeri alalım
                        string eklenenVeri = textBox2.Text;

                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // Güncelleme sorgusunu oluşturalım
                            string query = "UPDATE ondortpersonel SET maas =@EklenenVeri";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@EklenenVeri", eklenenVeri);

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            // Başarılı bir şekilde güncellendiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Maaşlar başarıyla güncellendi.");

                            //-------------------------------------------------------
                            string query1 = "UPDATE ondortpersonel SET toplam_maas = toplam_maas + @EklenenMiktar";
                            SqlCommand command1 = new SqlCommand(query1, connection);
                            command1.Parameters.AddWithValue("@EklenenMiktar", Convert.ToInt32(textBox2.Text));


                            command1.ExecuteNonQuery();


                            VerileriYukle();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Maaşları güncellerken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "15")
                {
                    try
                    {
                        // TextBox2'deki değeri alalım
                        string eklenenVeri = textBox2.Text;

                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // Güncelleme sorgusunu oluşturalım
                            string query = "UPDATE onbespersonel SET maas =@EklenenVeri";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@EklenenVeri", eklenenVeri);

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            // Başarılı bir şekilde güncellendiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Maaşlar başarıyla güncellendi.");


                            //-------------------------------------------------------
                            string query1 = "UPDATE onbespersonel SET toplam_maas = toplam_maas + @EklenenMiktar";
                            SqlCommand command1 = new SqlCommand(query1, connection);
                            command1.Parameters.AddWithValue("@EklenenMiktar", Convert.ToInt32(textBox2.Text));


                            command1.ExecuteNonQuery();

                            VerileriYukle();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Maaşları güncellerken bir hata oluştu: " + ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("Lütfen Tüm Alanları Doldurunuz");
            }


        }

        private void button3_Click(object sender, EventArgs e)
        {
            gizle();
            label1.Visible = true;
            button1.Visible = true;
            textBox2.Visible = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            gizle();
            label2.Visible = true;
            textBox3.Visible = true;
            textBox4.Visible = true;
            button4.Visible = true;
            label3.Visible = true;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            gizle();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (textBox3.Text!=""&&textBox4.Text!="")
            {

            
            if (textBox1.Text == "1")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Güncelleme sorgusunu oluşturalım
                        string query1 = "UPDATE birpersonel SET maas =@EklenenMiktar WHERE id = @ID";
                        SqlCommand command1 = new SqlCommand(query1, connection);
                        command1.Parameters.AddWithValue("@EklenenMiktar", Convert.ToInt32(textBox3.Text));
                        command1.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                        string query = "UPDATE birpersonel SET toplam_maas = toplam_maas + @EklenenMiktar WHERE id = @ID";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@EklenenMiktar", Convert.ToInt32(textBox3.Text));
                        command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                        // Bağlantıyı açalım ve sorguyu çalıştıralım
                        connection.Open();
                        command.ExecuteNonQuery();
                        command1.ExecuteNonQuery();

                        // Başarılı bir şekilde güncellendiğinde kullanıcıyı bilgilendir
                        VerileriYukle();
                        MessageBox.Show("Maaş başarıyla güncellendi.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Maaşı güncellerken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "2")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Güncelleme sorgusunu oluşturalım
                        string query1 = "UPDATE ikipersonel SET maas =@EklenenMiktar WHERE id = @ID";
                        SqlCommand command1 = new SqlCommand(query1, connection);
                        command1.Parameters.AddWithValue("@EklenenMiktar", Convert.ToInt32(textBox3.Text));
                        command1.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                        string query = "UPDATE ikipersonel SET toplam_maas = toplam_maas + @EklenenMiktar WHERE id = @ID";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@EklenenMiktar", Convert.ToInt32(textBox3.Text));
                        command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                        // Bağlantıyı açalım ve sorguyu çalıştıralım
                        connection.Open();
                        command.ExecuteNonQuery();
                        command1.ExecuteNonQuery();

                        // Başarılı bir şekilde güncellendiğinde kullanıcıyı bilgilendir
                        VerileriYukle();
                        MessageBox.Show("Maaş başarıyla güncellendi.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Maaşı güncellerken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "3")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Güncelleme sorgusunu oluşturalım
                        string query1 = "UPDATE ucpersonel SET maas =@EklenenMiktar WHERE id = @ID";
                        SqlCommand command1 = new SqlCommand(query1, connection);
                        command1.Parameters.AddWithValue("@EklenenMiktar", Convert.ToInt32(textBox3.Text));
                        command1.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                        string query = "UPDATE ucpersonel SET toplam_maas = toplam_maas + @EklenenMiktar WHERE id = @ID";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@EklenenMiktar", Convert.ToInt32(textBox3.Text));
                        command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                        // Bağlantıyı açalım ve sorguyu çalıştıralım
                        connection.Open();
                        command.ExecuteNonQuery();
                        command1.ExecuteNonQuery();

                        // Başarılı bir şekilde güncellendiğinde kullanıcıyı bilgilendir
                        VerileriYukle();
                        MessageBox.Show("Maaş başarıyla güncellendi.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Maaşı güncellerken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "4")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Güncelleme sorgusunu oluşturalım
                        string query1 = "UPDATE dortpersonel SET maas =@EklenenMiktar WHERE id = @ID";
                        SqlCommand command1 = new SqlCommand(query1, connection);
                        command1.Parameters.AddWithValue("@EklenenMiktar", Convert.ToInt32(textBox3.Text));
                        command1.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                        string query = "UPDATE dortpersonel SET toplam_maas = toplam_maas + @EklenenMiktar WHERE id = @ID";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@EklenenMiktar", Convert.ToInt32(textBox3.Text));
                        command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                        // Bağlantıyı açalım ve sorguyu çalıştıralım
                        connection.Open();
                        command.ExecuteNonQuery();
                        command1.ExecuteNonQuery();

                        // Başarılı bir şekilde güncellendiğinde kullanıcıyı bilgilendir
                        VerileriYukle();
                        MessageBox.Show("Maaş başarıyla güncellendi.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Maaşı güncellerken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "5")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Güncelleme sorgusunu oluşturalım
                        string query1 = "UPDATE bespersonel SET maas =@EklenenMiktar WHERE id = @ID";
                        SqlCommand command1 = new SqlCommand(query1, connection);
                        command1.Parameters.AddWithValue("@EklenenMiktar", Convert.ToInt32(textBox3.Text));
                        command1.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                        string query = "UPDATE bespersonel SET toplam_maas = toplam_maas + @EklenenMiktar WHERE id = @ID";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@EklenenMiktar", Convert.ToInt32(textBox3.Text));
                        command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                        // Bağlantıyı açalım ve sorguyu çalıştıralım
                        connection.Open();
                        command.ExecuteNonQuery();
                        command1.ExecuteNonQuery();

                        // Başarılı bir şekilde güncellendiğinde kullanıcıyı bilgilendir
                        VerileriYukle();
                        MessageBox.Show("Maaş başarıyla güncellendi.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Maaşı güncellerken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "6")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Güncelleme sorgusunu oluşturalım
                        string query1 = "UPDATE altipersonel SET maas =@EklenenMiktar WHERE id = @ID";
                        SqlCommand command1 = new SqlCommand(query1, connection);
                        command1.Parameters.AddWithValue("@EklenenMiktar", Convert.ToInt32(textBox3.Text));
                        command1.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                        string query = "UPDATE altipersonel SET toplam_maas = toplam_maas + @EklenenMiktar WHERE id = @ID";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@EklenenMiktar", Convert.ToInt32(textBox3.Text));
                        command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                        // Bağlantıyı açalım ve sorguyu çalıştıralım
                        connection.Open();
                        command.ExecuteNonQuery();
                        command1.ExecuteNonQuery();

                        // Başarılı bir şekilde güncellendiğinde kullanıcıyı bilgilendir
                        VerileriYukle();
                        MessageBox.Show("Maaş başarıyla güncellendi.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Maaşı güncellerken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "7")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Güncelleme sorgusunu oluşturalım
                        string query1 = "UPDATE yedipersonel SET maas =@EklenenMiktar WHERE id = @ID";
                        SqlCommand command1 = new SqlCommand(query1, connection);
                        command1.Parameters.AddWithValue("@EklenenMiktar", Convert.ToInt32(textBox3.Text));
                        command1.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                        string query = "UPDATE yedipersonel SET toplam_maas = toplam_maas + @EklenenMiktar WHERE id = @ID";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@EklenenMiktar", Convert.ToInt32(textBox3.Text));
                        command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                        // Bağlantıyı açalım ve sorguyu çalıştıralım
                        connection.Open();
                        command.ExecuteNonQuery();
                        command1.ExecuteNonQuery();

                        // Başarılı bir şekilde güncellendiğinde kullanıcıyı bilgilendir
                        VerileriYukle();
                        MessageBox.Show("Maaş başarıyla güncellendi.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Maaşı güncellerken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "8")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Güncelleme sorgusunu oluşturalım
                        string query1 = "UPDATE sekizpersonel SET maas =@EklenenMiktar WHERE id = @ID";
                        SqlCommand command1 = new SqlCommand(query1, connection);
                        command1.Parameters.AddWithValue("@EklenenMiktar", Convert.ToInt32(textBox3.Text));
                        command1.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                        string query = "UPDATE sekizpersonel SET toplam_maas = toplam_maas + @EklenenMiktar WHERE id = @ID";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@EklenenMiktar", Convert.ToInt32(textBox3.Text));
                        command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                        // Bağlantıyı açalım ve sorguyu çalıştıralım
                        connection.Open();
                        command.ExecuteNonQuery();
                        command1.ExecuteNonQuery();

                        // Başarılı bir şekilde güncellendiğinde kullanıcıyı bilgilendir
                        VerileriYukle();
                        MessageBox.Show("Maaş başarıyla güncellendi.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Maaşı güncellerken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "9")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Güncelleme sorgusunu oluşturalım
                        string query1 = "UPDATE dokuzpersonel SET maas =@EklenenMiktar WHERE id = @ID";
                        SqlCommand command1 = new SqlCommand(query1, connection);
                        command1.Parameters.AddWithValue("@EklenenMiktar", Convert.ToInt32(textBox3.Text));
                        command1.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                        string query = "UPDATE dokuzpersonel SET toplam_maas = toplam_maas + @EklenenMiktar WHERE id = @ID";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@EklenenMiktar", Convert.ToInt32(textBox3.Text));
                        command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                        // Bağlantıyı açalım ve sorguyu çalıştıralım
                        connection.Open();
                        command.ExecuteNonQuery();
                        command1.ExecuteNonQuery();

                        // Başarılı bir şekilde güncellendiğinde kullanıcıyı bilgilendir
                        VerileriYukle();
                        MessageBox.Show("Maaş başarıyla güncellendi.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Maaşı güncellerken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "10")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Güncelleme sorgusunu oluşturalım
                        string query1 = "UPDATE onpersonel SET maas =@EklenenMiktar WHERE id = @ID";
                        SqlCommand command1 = new SqlCommand(query1, connection);
                        command1.Parameters.AddWithValue("@EklenenMiktar", Convert.ToInt32(textBox3.Text));
                        command1.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                        string query = "UPDATE onpersonel SET toplam_maas = toplam_maas + @EklenenMiktar WHERE id = @ID";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@EklenenMiktar", Convert.ToInt32(textBox3.Text));
                        command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                        // Bağlantıyı açalım ve sorguyu çalıştıralım
                        connection.Open();
                        command.ExecuteNonQuery();
                        command1.ExecuteNonQuery();

                        // Başarılı bir şekilde güncellendiğinde kullanıcıyı bilgilendir
                        VerileriYukle();
                        MessageBox.Show("Maaş başarıyla güncellendi.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Maaşı güncellerken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "11")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Güncelleme sorgusunu oluşturalım
                        string query1 = "UPDATE onbirpersonel SET maas =@EklenenMiktar WHERE id = @ID";
                        SqlCommand command1 = new SqlCommand(query1, connection);
                        command1.Parameters.AddWithValue("@EklenenMiktar", Convert.ToInt32(textBox3.Text));
                        command1.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                        string query = "UPDATE onbirpersonel SET toplam_maas = toplam_maas + @EklenenMiktar WHERE id = @ID";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@EklenenMiktar", Convert.ToInt32(textBox3.Text));
                        command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                        // Bağlantıyı açalım ve sorguyu çalıştıralım
                        connection.Open();
                        command.ExecuteNonQuery();
                        command1.ExecuteNonQuery();

                        // Başarılı bir şekilde güncellendiğinde kullanıcıyı bilgilendir
                        VerileriYukle();
                        MessageBox.Show("Maaş başarıyla güncellendi.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Maaşı güncellerken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "12")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Güncelleme sorgusunu oluşturalım
                        string query1 = "UPDATE onikipersonel SET maas =@EklenenMiktar WHERE id = @ID";
                        SqlCommand command1 = new SqlCommand(query1, connection);
                        command1.Parameters.AddWithValue("@EklenenMiktar", Convert.ToInt32(textBox3.Text));
                        command1.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                        string query = "UPDATE onikipersonel SET toplam_maas = toplam_maas + @EklenenMiktar WHERE id = @ID";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@EklenenMiktar", Convert.ToInt32(textBox3.Text));
                        command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                        // Bağlantıyı açalım ve sorguyu çalıştıralım
                        connection.Open();
                        command.ExecuteNonQuery();
                        command1.ExecuteNonQuery();

                        // Başarılı bir şekilde güncellendiğinde kullanıcıyı bilgilendir
                        VerileriYukle();
                        MessageBox.Show("Maaş başarıyla güncellendi.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Maaşı güncellerken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "13")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Güncelleme sorgusunu oluşturalım
                        string query1 = "UPDATE onucpersonel SET maas =@EklenenMiktar WHERE id = @ID";
                        SqlCommand command1 = new SqlCommand(query1, connection);
                        command1.Parameters.AddWithValue("@EklenenMiktar", Convert.ToInt32(textBox3.Text));
                        command1.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                        string query = "UPDATE onucpersonel SET toplam_maas = toplam_maas + @EklenenMiktar WHERE id = @ID";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@EklenenMiktar", Convert.ToInt32(textBox3.Text));
                        command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                        // Bağlantıyı açalım ve sorguyu çalıştıralım
                        connection.Open();
                        command.ExecuteNonQuery();
                        command1.ExecuteNonQuery();

                        // Başarılı bir şekilde güncellendiğinde kullanıcıyı bilgilendir
                        VerileriYukle();
                        MessageBox.Show("Maaş başarıyla güncellendi.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Maaşı güncellerken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "14")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Güncelleme sorgusunu oluşturalım
                        string query1 = "UPDATE ondortpersonel SET maas =@EklenenMiktar WHERE id = @ID";
                        SqlCommand command1 = new SqlCommand(query1, connection);
                        command1.Parameters.AddWithValue("@EklenenMiktar", Convert.ToInt32(textBox3.Text));
                        command1.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                        string query = "UPDATE ondortpersonel SET toplam_maas = toplam_maas + @EklenenMiktar WHERE id = @ID";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@EklenenMiktar", Convert.ToInt32(textBox3.Text));
                        command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                        // Bağlantıyı açalım ve sorguyu çalıştıralım
                        connection.Open();
                        command.ExecuteNonQuery();
                        command1.ExecuteNonQuery();

                        // Başarılı bir şekilde güncellendiğinde kullanıcıyı bilgilendir
                        VerileriYukle();
                        MessageBox.Show("Maaş başarıyla güncellendi.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Maaşı güncellerken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "15")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Güncelleme sorgusunu oluşturalım
                        string query1 = "UPDATE onbespersonel SET maas =@EklenenMiktar WHERE id = @ID";
                        SqlCommand command1 = new SqlCommand(query1, connection);
                        command1.Parameters.AddWithValue("@EklenenMiktar", Convert.ToInt32(textBox3.Text));
                        command1.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                        string query = "UPDATE onbespersonel SET toplam_maas = toplam_maas + @EklenenMiktar WHERE id = @ID";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@EklenenMiktar", Convert.ToInt32(textBox3.Text));
                        command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                        // Bağlantıyı açalım ve sorguyu çalıştıralım
                        connection.Open();
                        command.ExecuteNonQuery();
                        command1.ExecuteNonQuery();

                        // Başarılı bir şekilde güncellendiğinde kullanıcıyı bilgilendir
                        VerileriYukle();
                        MessageBox.Show("Maaş başarıyla güncellendi.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Maaşı güncellerken bir hata oluştu: " + ex.Message);
                }
            }
            }
            else
            {
                MessageBox.Show("Lütfen Tüm Alanları Doldurunuz");
            }


        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            
        }
        private void PrintPage(object sender, PrintPageEventArgs e)
        {
            // Yazdırma için kullanılacak font
            Font font = new Font("Arial", 10);

            // Yazdırılacak metin için kullanılacak koordinatlar
            float x = 20;
            float y = 20;

            // DataGridView'deki her satırı dolaşarak içerikleri yazdırma
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                // DataGridView'deki her hücreyi dolaşarak içerikleri yazdırma
                foreach (DataGridViewCell cell in row.Cells)
                {
                    // Hücrenin içeriğini al ve yazdır
                    string cellValue = Convert.ToString(cell.Value);
                    e.Graphics.DrawString(cellValue, font, Brushes.Black, x, y);

                    // Bir sonraki hücreye geçmek için x koordinatını artır
                    x += cell.Size.Width;

                    // Hücreler arasında bir boşluk bırakmak için x koordinatını artır
                    x += 10; // Örnek bir boşluk bırakıyoruz, isteğinize göre değiştirebilirsiniz
                }

                // Bir sonraki satıra geçmek için y koordinatını artır ve x koordinatını başa al
                y += dataGridView1.Rows[0].Height;
                x = 20;

                // Sayfaya sığdığı sürece bir sonraki satırı yazdırmaya devam et
                if (y + dataGridView1.Rows[0].Height > e.MarginBounds.Bottom)
                {
                    e.HasMorePages = true;
                    return;
                }
            }

            e.HasMorePages = false;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            PrintDocument pd = new PrintDocument();
            pd.PrintPage += new PrintPageEventHandler(PrintPage);
            pd.Print();
        }
    }
}
