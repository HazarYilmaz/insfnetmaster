﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2.maas
{
    public partial class alacaklar : Form
    {
        public alacaklar()
        {
            InitializeComponent();
        }
        string connectionString = @"Data Source=.;Initial Catalog=gnc;Integrated Security=True;TrustServerCertificate=true";

        private void button1_Click(object sender, EventArgs e)
        {
            gizle();
            textBox2.Visible = true;
            textBox3.Visible = true;
            comboBox2.Visible = true;
            label1.Visible = true;
            label2.Visible = true;
            label3.Visible = true;
            button4.Visible = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            gizle();
            label5.Visible = true;
            textBox4.Visible = true;
            button5.Visible = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            gizle();
            label6.Visible = true;
            textBox5.Visible = true;
        }
        private void gizle()
        {
            textBox2.Visible = false;
            textBox3.Visible = false;
            comboBox2.Visible = false;
            label1.Visible = false;
            label2.Visible = false;
            label3.Visible = false;
            label6.Visible = false;
            button4.Visible = false;
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            label5.Visible = false;
            textBox4.Visible = false;
            button5.Visible = false;
            textBox5.Visible = false;

        }
        private void ResizeDataGridView()
        {
            // Sütunların otomatik boyutlandırılmasını sağla
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            // Satırların otomatik boyutlandırılmasını sağla
            dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;


        }
        private Dictionary<string, int> idDictionary = new Dictionary<string, int>();
        private void ComboBoxDoldur()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT insaat_adi,id FROM insaat_isim WHERE insaat_adi NOT IN ('1 (İsim Ekle)', '2 (İsim Ekle)', '3 (İsim Ekle)', '4 (İsim Ekle)', '5 (İsim Ekle)', '6 (İsim Ekle)', '7 (İsim Ekle)', '8 (İsim Ekle)', '9 (İsim Ekle)', '10 (İsim Ekle)', '11 (İsim Ekle)', '12 (İsim Ekle)', '13 (İsim Ekle)', '14 (İsim Ekle)', '15 (İsim Ekle)', '16 (İsim Ekle)', 'Admin' )";
                    SqlCommand command = new SqlCommand(query, connection);
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        string insaatAdi = reader["insaat_adi"].ToString();
                        comboBox1.Items.Add(insaatAdi);
                        // ComboBox'a her bir öğe eklenirken, karşılık gelen ID'yi bir dictionary'e ekleyebiliriz
                        int id = Convert.ToInt32(reader["id"]);
                        idDictionary.Add(insaatAdi, id);
                    }
                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
            }

        }

        private void alacaklar_Load(object sender, EventArgs e)
        {
            gizle();
            VerileriYukle();
            ComboBoxDoldur();
            dataGridView1.ReadOnly = true;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string secilenInsaatAdi = comboBox1.SelectedItem.ToString();

            // Seçilen inşaat adının ID'sini alıyoruz
            int secilenInsaatId = idDictionary[secilenInsaatAdi];

            // TextBox'a ID'yi yazdırıyoruz
            textBox1.Text = secilenInsaatId.ToString();
            VerileriYukle();
            ResizeDataGridView();
        }
        private void VerileriYukle()
        {
            if (textBox1.Text == "1")
            {


                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Veritabanından belirli sütunları seçerek personel bilgilerini alacak sorguyu oluşturalım
                        string query = "SELECT id as 'İd',odeme_turu AS 'Ödeme Türü', miktar AS 'Miktar', odeme_yontemi AS 'Ödeme Yönetmi' FROM biralacak";
                        SqlCommand command = new SqlCommand(query, connection);

                        // SqlDataAdapter nesnesi oluşturalım ve verileri yükleyelim
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // DataGridView'e verileri yükleyelim
                        dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "2")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Veritabanından belirli sütunları seçerek personel bilgilerini alacak sorguyu oluşturalım
                        string query = "SELECT id as 'İd',odeme_turu AS 'Ödeme Türü', miktar AS 'Miktar', odeme_yontemi AS 'Ödeme Yönetmi' FROM ikialacak";
                        SqlCommand command = new SqlCommand(query, connection);

                        // SqlDataAdapter nesnesi oluşturalım ve verileri yükleyelim
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // DataGridView'e verileri yükleyelim
                        dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "3")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Veritabanından belirli sütunları seçerek personel bilgilerini alacak sorguyu oluşturalım
                        string query = "SELECT id as 'İd',odeme_turu AS 'Ödeme Türü', miktar AS 'Miktar', odeme_yontemi AS 'Ödeme Yönetmi' FROM ucalacak";
                        SqlCommand command = new SqlCommand(query, connection);

                        // SqlDataAdapter nesnesi oluşturalım ve verileri yükleyelim
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // DataGridView'e verileri yükleyelim
                        dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "4")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Veritabanından belirli sütunları seçerek personel bilgilerini alacak sorguyu oluşturalım
                        string query = "SELECT id AS 'İd', odeme_turu AS 'Ödeme Türü', miktar AS 'Miktar', odeme_yontemi AS 'Ödeme Yönetmi' FROM dortalacak";
                        SqlCommand command = new SqlCommand(query, connection);

                        // SqlDataAdapter nesnesi oluşturalım ve verileri yükleyelim
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // DataGridView'e verileri yükleyelim
                        dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "5")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Veritabanından belirli sütunları seçerek personel bilgilerini alacak sorguyu oluşturalım
                        string query = "SELECT id AS 'İd', odeme_turu AS 'Ödeme Türü', miktar AS 'Miktar', odeme_yontemi AS 'Ödeme Yönetmi' FROM besalacak";
                        SqlCommand command = new SqlCommand(query, connection);

                        // SqlDataAdapter nesnesi oluşturalım ve verileri yükleyelim
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // DataGridView'e verileri yükleyelim
                        dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "6")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Veritabanından belirli sütunları seçerek personel bilgilerini alacak sorguyu oluşturalım
                        string query = "SELECT id AS 'İd', odeme_turu AS 'Ödeme Türü', miktar AS 'Miktar', odeme_yontemi AS 'Ödeme Yönetmi' FROM altialacak";
                        SqlCommand command = new SqlCommand(query, connection);

                        // SqlDataAdapter nesnesi oluşturalım ve verileri yükleyelim
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // DataGridView'e verileri yükleyelim
                        dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "7")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Veritabanından belirli sütunları seçerek personel bilgilerini alacak sorguyu oluşturalım
                        string query = "SELECT id AS 'İd', odeme_turu AS 'Ödeme Türü', miktar AS 'Miktar', odeme_yontemi AS 'Ödeme Yönetmi' FROM yedialacak";
                        SqlCommand command = new SqlCommand(query, connection);

                        // SqlDataAdapter nesnesi oluşturalım ve verileri yükleyelim
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // DataGridView'e verileri yükleyelim
                        dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "8")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Veritabanından belirli sütunları seçerek personel bilgilerini alacak sorguyu oluşturalım
                        string query = "SELECT id AS 'İd', odeme_turu AS 'Ödeme Türü', miktar AS 'Miktar', odeme_yontemi AS 'Ödeme Yönetmi' FROM sekizalacak";
                        SqlCommand command = new SqlCommand(query, connection);

                        // SqlDataAdapter nesnesi oluşturalım ve verileri yükleyelim
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // DataGridView'e verileri yükleyelim
                        dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "9")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Veritabanından belirli sütunları seçerek personel bilgilerini alacak sorguyu oluşturalım
                        string query = "SELECT id AS 'İd', odeme_turu AS 'Ödeme Türü', miktar AS 'Miktar', odeme_yontemi AS 'Ödeme Yönetmi' FROM dokuzalacak";
                        SqlCommand command = new SqlCommand(query, connection);

                        // SqlDataAdapter nesnesi oluşturalım ve verileri yükleyelim
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // DataGridView'e verileri yükleyelim
                        dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "10")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Veritabanından belirli sütunları seçerek personel bilgilerini alacak sorguyu oluşturalım
                        string query = "SELECT id AS 'İd', odeme_turu AS 'Ödeme Türü', miktar AS 'Miktar', odeme_yontemi AS 'Ödeme Yönetmi' FROM onalacak";
                        SqlCommand command = new SqlCommand(query, connection);

                        // SqlDataAdapter nesnesi oluşturalım ve verileri yükleyelim
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // DataGridView'e verileri yükleyelim
                        dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "11")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Veritabanından belirli sütunları seçerek personel bilgilerini alacak sorguyu oluşturalım
                        string query = "SELECT id AS 'İd', odeme_turu AS 'Ödeme Türü', miktar AS 'Miktar', odeme_yontemi AS 'Ödeme Yönetmi' FROM onbiralacak";
                        SqlCommand command = new SqlCommand(query, connection);

                        // SqlDataAdapter nesnesi oluşturalım ve verileri yükleyelim
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // DataGridView'e verileri yükleyelim
                        dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "12")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Veritabanından belirli sütunları seçerek personel bilgilerini alacak sorguyu oluşturalım
                        string query = "SELECT id AS 'İd', odeme_turu AS 'Ödeme Türü', miktar AS 'Miktar', odeme_yontemi AS 'Ödeme Yönetmi' FROM onikialacak";
                        SqlCommand command = new SqlCommand(query, connection);

                        // SqlDataAdapter nesnesi oluşturalım ve verileri yükleyelim
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // DataGridView'e verileri yükleyelim
                        dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "13")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Veritabanından belirli sütunları seçerek personel bilgilerini alacak sorguyu oluşturalım
                        string query = "SELECT id AS 'İd', odeme_turu AS 'Ödeme Türü', miktar AS 'Miktar', odeme_yontemi AS 'Ödeme Yönetmi' FROM onucalacak";
                        SqlCommand command = new SqlCommand(query, connection);

                        // SqlDataAdapter nesnesi oluşturalım ve verileri yükleyelim
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // DataGridView'e verileri yükleyelim
                        dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "14")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Veritabanından belirli sütunları seçerek personel bilgilerini alacak sorguyu oluşturalım
                        string query = "SELECT id AS 'İd', odeme_turu AS 'Ödeme Türü', miktar AS 'Miktar', odeme_yontemi AS 'Ödeme Yönetmi' FROM ondortalacak";
                        SqlCommand command = new SqlCommand(query, connection);

                        // SqlDataAdapter nesnesi oluşturalım ve verileri yükleyelim
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // DataGridView'e verileri yükleyelim
                        dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
                }
            }
            else if (textBox1.Text == "15")
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        // Veritabanından belirli sütunları seçerek personel bilgilerini alacak sorguyu oluşturalım
                        string query = "SELECT id AS 'İd', odeme_turu AS 'Ödeme Türü', miktar AS 'Miktar', odeme_yontemi AS 'Ödeme Yönetmi' FROM onbesalacak";
                        SqlCommand command = new SqlCommand(query, connection);

                        // SqlDataAdapter nesnesi oluşturalım ve verileri yükleyelim
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // DataGridView'e verileri yükleyelim
                        dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
                }
            }

        }

        private void button8_Click(object sender, EventArgs e)
        {
            VerileriYukle();
            gizle();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (textBox2.Text != "" && textBox3.Text != "" && comboBox2.SelectedItem != null)
            {


                if (textBox1.Text == "1")
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // INSERT INTO sorgusunu oluşturalım
                            string query = "INSERT INTO biralacak (odeme_turu, miktar, odeme_yontemi) VALUES (@OdemeTuru, @Miktar, @OdemeYontemi)";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@OdemeTuru", textBox2.Text);
                            command.Parameters.AddWithValue("@Miktar", textBox3.Text);
                            command.Parameters.AddWithValue("@OdemeYontemi", comboBox2.SelectedItem.ToString());

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            // Başarılı bir şekilde eklendiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Ödeme başarıyla eklendi.");
                            VerileriYukle();
                            gizle();

                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ödeme eklenirken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "2")
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // INSERT INTO sorgusunu oluşturalım
                            string query = "INSERT INTO ikialacak (odeme_turu, miktar, odeme_yontemi) VALUES (@OdemeTuru, @Miktar, @OdemeYontemi)";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@OdemeTuru", textBox2.Text);
                            command.Parameters.AddWithValue("@Miktar", textBox3.Text);
                            command.Parameters.AddWithValue("@OdemeYontemi", comboBox2.SelectedItem.ToString());

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            // Başarılı bir şekilde eklendiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Ödeme başarıyla eklendi.");
                            VerileriYukle();
                            gizle();

                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ödeme eklenirken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "3")
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // INSERT INTO sorgusunu oluşturalım
                            string query = "INSERT INTO ucalacak (odeme_turu, miktar, odeme_yontemi) VALUES (@OdemeTuru, @Miktar, @OdemeYontemi)";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@OdemeTuru", textBox2.Text);
                            command.Parameters.AddWithValue("@Miktar", textBox3.Text);
                            command.Parameters.AddWithValue("@OdemeYontemi", comboBox2.SelectedItem.ToString());

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            // Başarılı bir şekilde eklendiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Ödeme başarıyla eklendi.");
                            VerileriYukle();
                            gizle();

                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ödeme eklenirken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "4")
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // INSERT INTO sorgusunu oluşturalım
                            string query = "INSERT INTO dortalacak (odeme_turu, miktar, odeme_yontemi) VALUES (@OdemeTuru, @Miktar, @OdemeYontemi)";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@OdemeTuru", textBox2.Text);
                            command.Parameters.AddWithValue("@Miktar", textBox3.Text);
                            command.Parameters.AddWithValue("@OdemeYontemi", comboBox2.SelectedItem.ToString());

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            // Başarılı bir şekilde eklendiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Ödeme başarıyla eklendi.");
                            VerileriYukle();
                            gizle();

                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ödeme eklenirken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "5")
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // INSERT INTO sorgusunu oluşturalım
                            string query = "INSERT INTO besalacak (odeme_turu, miktar, odeme_yontemi) VALUES (@OdemeTuru, @Miktar, @OdemeYontemi)";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@OdemeTuru", textBox2.Text);
                            command.Parameters.AddWithValue("@Miktar", textBox3.Text);
                            command.Parameters.AddWithValue("@OdemeYontemi", comboBox2.SelectedItem.ToString());

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            // Başarılı bir şekilde eklendiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Ödeme başarıyla eklendi.");
                            VerileriYukle();
                            gizle();

                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ödeme eklenirken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "6")
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // INSERT INTO sorgusunu oluşturalım
                            string query = "INSERT INTO altialacak (odeme_turu, miktar, odeme_yontemi) VALUES (@OdemeTuru, @Miktar, @OdemeYontemi)";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@OdemeTuru", textBox2.Text);
                            command.Parameters.AddWithValue("@Miktar", textBox3.Text);
                            command.Parameters.AddWithValue("@OdemeYontemi", comboBox2.SelectedItem.ToString());

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            // Başarılı bir şekilde eklendiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Ödeme başarıyla eklendi.");
                            VerileriYukle();
                            gizle();

                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ödeme eklenirken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "7")
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // INSERT INTO sorgusunu oluşturalım
                            string query = "INSERT INTO yedialacak (odeme_turu, miktar, odeme_yontemi) VALUES (@OdemeTuru, @Miktar, @OdemeYontemi)";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@OdemeTuru", textBox2.Text);
                            command.Parameters.AddWithValue("@Miktar", textBox3.Text);
                            command.Parameters.AddWithValue("@OdemeYontemi", comboBox2.SelectedItem.ToString());

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            // Başarılı bir şekilde eklendiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Ödeme başarıyla eklendi.");
                            VerileriYukle();
                            gizle();

                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ödeme eklenirken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "8")
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // INSERT INTO sorgusunu oluşturalım
                            string query = "INSERT INTO sekizalacak (odeme_turu, miktar, odeme_yontemi) VALUES (@OdemeTuru, @Miktar, @OdemeYontemi)";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@OdemeTuru", textBox2.Text);
                            command.Parameters.AddWithValue("@Miktar", textBox3.Text);
                            command.Parameters.AddWithValue("@OdemeYontemi", comboBox2.SelectedItem.ToString());

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            // Başarılı bir şekilde eklendiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Ödeme başarıyla eklendi.");
                            VerileriYukle();
                            gizle();

                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ödeme eklenirken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "9")
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // INSERT INTO sorgusunu oluşturalım
                            string query = "INSERT INTO dokuzalacak (odeme_turu, miktar, odeme_yontemi) VALUES (@OdemeTuru, @Miktar, @OdemeYontemi)";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@OdemeTuru", textBox2.Text);
                            command.Parameters.AddWithValue("@Miktar", textBox3.Text);
                            command.Parameters.AddWithValue("@OdemeYontemi", comboBox2.SelectedItem.ToString());

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            // Başarılı bir şekilde eklendiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Ödeme başarıyla eklendi.");
                            VerileriYukle();
                            gizle();

                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ödeme eklenirken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "10")
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // INSERT INTO sorgusunu oluşturalım
                            string query = "INSERT INTO onalacak (odeme_turu, miktar, odeme_yontemi) VALUES (@OdemeTuru, @Miktar, @OdemeYontemi)";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@OdemeTuru", textBox2.Text);
                            command.Parameters.AddWithValue("@Miktar", textBox3.Text);
                            command.Parameters.AddWithValue("@OdemeYontemi", comboBox2.SelectedItem.ToString());

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            // Başarılı bir şekilde eklendiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Ödeme başarıyla eklendi.");
                            VerileriYukle();
                            gizle();

                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ödeme eklenirken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "11")
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // INSERT INTO sorgusunu oluşturalım
                            string query = "INSERT INTO onbiralacak (odeme_turu, miktar, odeme_yontemi) VALUES (@OdemeTuru, @Miktar, @OdemeYontemi)";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@OdemeTuru", textBox2.Text);
                            command.Parameters.AddWithValue("@Miktar", textBox3.Text);
                            command.Parameters.AddWithValue("@OdemeYontemi", comboBox2.SelectedItem.ToString());

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            // Başarılı bir şekilde eklendiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Ödeme başarıyla eklendi.");
                            VerileriYukle();
                            gizle();

                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ödeme eklenirken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "12")
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // INSERT INTO sorgusunu oluşturalım
                            string query = "INSERT INTO onikialacak (odeme_turu, miktar, odeme_yontemi) VALUES (@OdemeTuru, @Miktar, @OdemeYontemi)";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@OdemeTuru", textBox2.Text);
                            command.Parameters.AddWithValue("@Miktar", textBox3.Text);
                            command.Parameters.AddWithValue("@OdemeYontemi", comboBox2.SelectedItem.ToString());

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            // Başarılı bir şekilde eklendiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Ödeme başarıyla eklendi.");
                            VerileriYukle();
                            gizle();

                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ödeme eklenirken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "13")
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // INSERT INTO sorgusunu oluşturalım
                            string query = "INSERT INTO onucalacak (odeme_turu, miktar, odeme_yontemi) VALUES (@OdemeTuru, @Miktar, @OdemeYontemi)";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@OdemeTuru", textBox2.Text);
                            command.Parameters.AddWithValue("@Miktar", textBox3.Text);
                            command.Parameters.AddWithValue("@OdemeYontemi", comboBox2.SelectedItem.ToString());

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            // Başarılı bir şekilde eklendiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Ödeme başarıyla eklendi.");
                            VerileriYukle();
                            gizle();

                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ödeme eklenirken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "14")
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // INSERT INTO sorgusunu oluşturalım
                            string query = "INSERT INTO ondortalacak (odeme_turu, miktar, odeme_yontemi) VALUES (@OdemeTuru, @Miktar, @OdemeYontemi)";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@OdemeTuru", textBox2.Text);
                            command.Parameters.AddWithValue("@Miktar", textBox3.Text);
                            command.Parameters.AddWithValue("@OdemeYontemi", comboBox2.SelectedItem.ToString());

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            // Başarılı bir şekilde eklendiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Ödeme başarıyla eklendi.");
                            VerileriYukle();
                            gizle();

                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ödeme eklenirken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "15")
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // INSERT INTO sorgusunu oluşturalım
                            string query = "INSERT INTO onbesalacak (odeme_turu, miktar, odeme_yontemi) VALUES (@OdemeTuru, @Miktar, @OdemeYontemi)";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@OdemeTuru", textBox2.Text);
                            command.Parameters.AddWithValue("@Miktar", textBox3.Text);
                            command.Parameters.AddWithValue("@OdemeYontemi", comboBox2.SelectedItem.ToString());

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            // Başarılı bir şekilde eklendiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Ödeme başarıyla eklendi.");
                            VerileriYukle();
                            gizle();

                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ödeme eklenirken bir hata oluştu: " + ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("Lütfen Tüm Alanları Doldurun.");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (textBox4.Text != "")
            {


                if (textBox1.Text == "1")
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // DELETE FROM sorgusunu oluşturalım
                            string query = "DELETE FROM biralacak WHERE id = @ID";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            VerileriYukle();
                            gizle();
                            // Başarılı bir şekilde silindiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Öğe başarıyla silindi.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Öğe silinirken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "2")
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // DELETE FROM sorgusunu oluşturalım
                            string query = "DELETE FROM ikialacak WHERE id = @ID";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            VerileriYukle();
                            gizle();
                            // Başarılı bir şekilde silindiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Öğe başarıyla silindi.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Öğe silinirken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "3")
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // DELETE FROM sorgusunu oluşturalım
                            string query = "DELETE FROM ucalacak WHERE id = @ID";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            VerileriYukle();
                            gizle();
                            // Başarılı bir şekilde silindiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Öğe başarıyla silindi.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Öğe silinirken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "4")
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // DELETE FROM sorgusunu oluşturalım
                            string query = "DELETE FROM dortalacak WHERE id = @ID";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            VerileriYukle();
                            gizle();
                            // Başarılı bir şekilde silindiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Öğe başarıyla silindi.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Öğe silinirken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "5")
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // DELETE FROM sorgusunu oluşturalım
                            string query = "DELETE FROM besalacak WHERE id = @ID";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            VerileriYukle();
                            gizle();
                            // Başarılı bir şekilde silindiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Öğe başarıyla silindi.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Öğe silinirken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "6")
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // DELETE FROM sorgusunu oluşturalım
                            string query = "DELETE FROM altialacak WHERE id = @ID";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            VerileriYukle();
                            gizle();
                            // Başarılı bir şekilde silindiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Öğe başarıyla silindi.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Öğe silinirken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "7")
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // DELETE FROM sorgusunu oluşturalım
                            string query = "DELETE FROM yedialacak WHERE id = @ID";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            VerileriYukle();
                            gizle();
                            // Başarılı bir şekilde silindiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Öğe başarıyla silindi.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Öğe silinirken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "8")
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // DELETE FROM sorgusunu oluşturalım
                            string query = "DELETE FROM sekizalacak WHERE id = @ID";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            VerileriYukle();
                            gizle();
                            // Başarılı bir şekilde silindiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Öğe başarıyla silindi.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Öğe silinirken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "9")
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // DELETE FROM sorgusunu oluşturalım
                            string query = "DELETE FROM dokuzalacak WHERE id = @ID";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            VerileriYukle();
                            gizle();
                            // Başarılı bir şekilde silindiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Öğe başarıyla silindi.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Öğe silinirken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "10")
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // DELETE FROM sorgusunu oluşturalım
                            string query = "DELETE FROM onalacak WHERE id = @ID";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            VerileriYukle();
                            gizle();
                            // Başarılı bir şekilde silindiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Öğe başarıyla silindi.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Öğe silinirken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "11")
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // DELETE FROM sorgusunu oluşturalım
                            string query = "DELETE FROM onbiralacak WHERE id = @ID";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            VerileriYukle();
                            gizle();
                            // Başarılı bir şekilde silindiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Öğe başarıyla silindi.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Öğe silinirken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "12")
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // DELETE FROM sorgusunu oluşturalım
                            string query = "DELETE FROM onikialacak WHERE id = @ID";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            VerileriYukle();
                            gizle();
                            // Başarılı bir şekilde silindiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Öğe başarıyla silindi.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Öğe silinirken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "13")
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // DELETE FROM sorgusunu oluşturalım
                            string query = "DELETE FROM onucalacak WHERE id = @ID";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            VerileriYukle();
                            gizle();
                            // Başarılı bir şekilde silindiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Öğe başarıyla silindi.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Öğe silinirken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "14")
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // DELETE FROM sorgusunu oluşturalım
                            string query = "DELETE FROM ondortalacak WHERE id = @ID";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            VerileriYukle();
                            gizle();
                            // Başarılı bir şekilde silindiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Öğe başarıyla silindi.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Öğe silinirken bir hata oluştu: " + ex.Message);
                    }
                }
                else if (textBox1.Text == "15")
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // DELETE FROM sorgusunu oluşturalım
                            string query = "DELETE FROM onbesalacak WHERE id = @ID";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@ID", Convert.ToInt32(textBox4.Text));

                            // Bağlantıyı açalım ve sorguyu çalıştıralım
                            connection.Open();
                            command.ExecuteNonQuery();

                            VerileriYukle();
                            gizle();
                            // Başarılı bir şekilde silindiğinde kullanıcıyı bilgilendir
                            MessageBox.Show("Öğe başarıyla silindi.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Öğe silinirken bir hata oluştu: " + ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("Lütfen Tüm Alanları Doldurun ");
            }
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            string searchText = textBox5.Text;

            // Arama fonksiyonunu çağır
            SearchAndHighlight(searchText);
        }
        private void SearchAndHighlight(string searchText)
        {
            // DataGridView'i dolaşarak arama yapma
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                // Her bir hücreyi kontrol etme
                foreach (DataGridViewCell cell in row.Cells)
                {
                    // Hücrede aranan metni bulma
                    if (cell.Value != null && cell.Value.ToString().IndexOf(searchText, StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        // Eğer aranan metin bulunduysa, hücreyi ve ilgili sütunu gösterme
                        dataGridView1.CurrentCell = cell;
                        dataGridView1.FirstDisplayedScrollingRowIndex = row.Index;
                        dataGridView1.Columns[cell.ColumnIndex].Visible = true;

                        // Hücreyi seçme
                        dataGridView1.Rows[cell.RowIndex].Selected = true;

                        // Aramayı sonlandır
                        return;
                    }
                }
            }

            // Eğer aranan metin bulunamazsa, kullanıcıya bilgi ver
            MessageBox.Show("Aranan metin bulunamadı.");
            gizle();
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Tüm verileri silmek istediğinizden emin misiniz?", "Onay", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                if (textBox1.Text == "1")
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            string query = "DELETE FROM biralacak";
                            SqlCommand command = new SqlCommand(query, connection);
                            connection.Open();
                            command.ExecuteNonQuery();
                        }
                        VerileriYukle();
                        MessageBox.Show("Tüm veriler başarıyla silindi.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Veriler silinirken bir hata oluştu: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }


                }
                else if (textBox1.Text == "2")
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            string query = "DELETE FROM ikialacak";
                            SqlCommand command = new SqlCommand(query, connection);
                            connection.Open();
                            command.ExecuteNonQuery();
                        }
                        VerileriYukle();
                        MessageBox.Show("Tüm veriler başarıyla silindi.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Veriler silinirken bir hata oluştu: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (textBox1.Text == "3")
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            string query = "DELETE FROM ucalacak";
                            SqlCommand command = new SqlCommand(query, connection);
                            connection.Open();
                            command.ExecuteNonQuery();
                        }
                        VerileriYukle();
                        MessageBox.Show("Tüm veriler başarıyla silindi.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Veriler silinirken bir hata oluştu: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (textBox1.Text == "4")
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            string query = "DELETE FROM dortalacak";
                            SqlCommand command = new SqlCommand(query, connection);
                            connection.Open();
                            command.ExecuteNonQuery();
                        }
                        VerileriYukle();
                        MessageBox.Show("Tüm veriler başarıyla silindi.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Veriler silinirken bir hata oluştu: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (textBox1.Text == "5")
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            string query = "DELETE FROM besalacak";
                            SqlCommand command = new SqlCommand(query, connection);
                            connection.Open();
                            command.ExecuteNonQuery();
                        }
                        VerileriYukle();
                        MessageBox.Show("Tüm veriler başarıyla silindi.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Veriler silinirken bir hata oluştu: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (textBox1.Text == "6")
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            string query = "DELETE FROM altialacak";
                            SqlCommand command = new SqlCommand(query, connection);
                            connection.Open();
                            command.ExecuteNonQuery();
                        }
                        VerileriYukle();
                        MessageBox.Show("Tüm veriler başarıyla silindi.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Veriler silinirken bir hata oluştu: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (textBox1.Text == "7")
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            string query = "DELETE FROM yedialacak";
                            SqlCommand command = new SqlCommand(query, connection);
                            connection.Open();
                            command.ExecuteNonQuery();
                        }
                        VerileriYukle();
                        MessageBox.Show("Tüm veriler başarıyla silindi.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Veriler silinirken bir hata oluştu: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (textBox1.Text == "8")
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            string query = "DELETE FROM sekizalacak";
                            SqlCommand command = new SqlCommand(query, connection);
                            connection.Open();
                            command.ExecuteNonQuery();
                        }
                        VerileriYukle();
                        MessageBox.Show("Tüm veriler başarıyla silindi.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Veriler silinirken bir hata oluştu: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (textBox1.Text == "9")
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            string query = "DELETE FROM dokuzalacak";
                            SqlCommand command = new SqlCommand(query, connection);
                            connection.Open();
                            command.ExecuteNonQuery();
                        }
                        VerileriYukle();
                        MessageBox.Show("Tüm veriler başarıyla silindi.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Veriler silinirken bir hata oluştu: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (textBox1.Text == "10")
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            string query = "DELETE FROM onalacak";
                            SqlCommand command = new SqlCommand(query, connection);
                            connection.Open();
                            command.ExecuteNonQuery();
                        }
                        VerileriYukle();
                        MessageBox.Show("Tüm veriler başarıyla silindi.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Veriler silinirken bir hata oluştu: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (textBox1.Text == "11")
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            string query = "DELETE FROM onbiralacak";
                            SqlCommand command = new SqlCommand(query, connection);
                            connection.Open();
                            command.ExecuteNonQuery();
                        }
                        VerileriYukle();
                        MessageBox.Show("Tüm veriler başarıyla silindi.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Veriler silinirken bir hata oluştu: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (textBox1.Text == "12")
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            string query = "DELETE FROM onikialacak";
                            SqlCommand command = new SqlCommand(query, connection);
                            connection.Open();
                            command.ExecuteNonQuery();
                        }
                        VerileriYukle();
                        MessageBox.Show("Tüm veriler başarıyla silindi.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Veriler silinirken bir hata oluştu: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (textBox1.Text == "13")
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            string query = "DELETE FROM onucalacak";
                            SqlCommand command = new SqlCommand(query, connection);
                            connection.Open();
                            command.ExecuteNonQuery();
                        }
                        VerileriYukle();
                        MessageBox.Show("Tüm veriler başarıyla silindi.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Veriler silinirken bir hata oluştu: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (textBox1.Text == "14")
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            string query = "DELETE FROM ondortalacak";
                            SqlCommand command = new SqlCommand(query, connection);
                            connection.Open();
                            command.ExecuteNonQuery();
                        }
                        VerileriYukle();
                        MessageBox.Show("Tüm veriler başarıyla silindi.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Veriler silinirken bir hata oluştu: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (textBox1.Text == "15")
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            string query = "DELETE FROM onbesalacak";
                            SqlCommand command = new SqlCommand(query, connection);
                            connection.Open();
                            command.ExecuteNonQuery();
                        }
                        VerileriYukle();
                        MessageBox.Show("Tüm veriler başarıyla silindi.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Veriler silinirken bir hata oluştu: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }




            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            PrintDocument pd = new PrintDocument();
            pd.PrintPage += new PrintPageEventHandler(PrintPage);
            pd.Print();
        }
        private void PrintPage(object sender, PrintPageEventArgs e)
        {
            // Yazdırma için kullanılacak font
            Font font = new Font("Arial", 10);

            // Yazdırılacak metin için kullanılacak koordinatlar
            float x = 20;
            float y = 20;

            // DataGridView'deki her satırı dolaşarak içerikleri yazdırma
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                // DataGridView'deki her hücreyi dolaşarak içerikleri yazdırma
                foreach (DataGridViewCell cell in row.Cells)
                {
                    // Hücrenin içeriğini al ve yazdır
                    string cellValue = Convert.ToString(cell.Value);
                    e.Graphics.DrawString(cellValue, font, Brushes.Black, x, y);

                    // Bir sonraki hücreye geçmek için x koordinatını artır
                    x += cell.Size.Width;

                    // Hücreler arasında bir boşluk bırakmak için x koordinatını artır
                    x += 10; // Örnek bir boşluk bırakıyoruz, isteğinize göre değiştirebilirsiniz
                }

                // Bir sonraki satıra geçmek için y koordinatını artır ve x koordinatını başa al
                y += dataGridView1.Rows[0].Height;
                x = 20;

                // Sayfaya sığdığı sürece bir sonraki satırı yazdırmaya devam et
                if (y + dataGridView1.Rows[0].Height > e.MarginBounds.Bottom)
                {
                    e.HasMorePages = true;
                    return;
                }
            }

            e.HasMorePages = false;
        }
    }
}
