﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp2.maas;
using WindowsFormsApp2.personel;
using WindowsFormsApp2.raporlar;

namespace WindowsFormsApp2.menu
{
    public partial class menu14 : Form
    {
        string connectionString = @"Data Source=.;Initial Catalog=gnc;Integrated Security=True;TrustServerCertificate=true";

        public menu14()
        {
            InitializeComponent();
        }
        bool formTasiniyor = false;
        Point baslangicNoktasi = new Point(0, 0);

        private void menu14_Load(object sender, EventArgs e)
        {
            FetchDataFromDatabase();
            yenile();
        }
        private void yenile()
        {
            try
            {
                int aktifSayisi = 0;

                // SQL sorgusuyla "birapart" tablosundaki aktif kayıt sayısını al
                string query = "SELECT COUNT(*) FROM onbesapart WHERE durum = 'Aktif'";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    connection.Open();
                    aktifSayisi = (int)command.ExecuteScalar();
                }

                // Aktif kayıt sayısını Label kontrolüne yaz
                label5.Text = aktifSayisi.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Aktif kayıt sayısı alınırken bir hata oluştu: " + ex.Message);
            }
            try
            {
                string toplamMiktar = "";

                // SQL sorgusuyla "biralacak" tablosundaki miktar sütunundaki değerlerin toplamını al
                string query = "SELECT SUM(miktar) FROM onbesalacak";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    connection.Open();
                    // Toplam miktarı double türünde alıyoruz
                    double result = Convert.ToDouble(command.ExecuteScalar());
                    // Toplam miktarı formatlayarak stringe çeviriyoruz
                    toplamMiktar = result.ToString("N0");
                }

                // Toplam miktarın sonuna "TL" işaretini ekleyerek Label kontrolüne yaz
                label6.Text = toplamMiktar + " ₺";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Toplam miktar alınırken bir hata oluştu: " + ex.Message);
            }
            try
            {
                string toplamMiktar = "";

                // SQL sorgusuyla "biralacak" tablosundaki miktar sütunundaki değerlerin toplamını al
                string query = "SELECT SUM(miktar) FROM odemeonbes";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    connection.Open();
                    // Toplam miktarı double türünde alıyoruz
                    double result = Convert.ToDouble(command.ExecuteScalar());
                    // Toplam miktarı formatlayarak stringe çeviriyoruz
                    toplamMiktar = result.ToString("N0");
                }

                // Toplam miktarın sonuna "TL" işaretini ekleyerek Label kontrolüne yaz
                label7.Text = toplamMiktar + " ₺";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Toplam miktar alınırken bir hata oluştu: " + ex.Message);
            }
        }
        public void FetchDataFromDatabase()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    // SQL sorgusu
                    string query = "SELECT insaat_adi FROM insaat_isim WHERE id = 15";


                    // SqlCommand oluşturma
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // Bağlantıyı açma
                        connection.Open();

                        // Veriyi okuma
                        SqlDataReader reader = command.ExecuteReader();

                        // Veriyi oku
                        while (reader.Read())
                        {
                            // Label2'ye yazdır

                            label1.Text = reader["insaat_adi"].ToString();
                        }

                        // Okuyucuyu kapat
                        reader.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            this.Close();
            secim secim = new secim();
            secim.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Uygulamadan Çıkmak Üzeresin Devam Etmek İstiyor Musunuz?", "Emin Misin", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                System.Windows.Forms.Application.Exit();

            }
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            formTasiniyor = true;
            baslangicNoktasi = new Point(e.X, e.Y);
        }

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            formTasiniyor = false;
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (formTasiniyor)
            {
                Point p = PointToScreen(e.Location);
                Location = new Point(p.X - this.baslangicNoktasi.X, p.Y - this.baslangicNoktasi.Y);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            menu14personel menuform = new menu14personel();
            menuform.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            personelmaas maasform = new personelmaas();
            maasform.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            odemeler odemeform = new odemeler();
            odemeform.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            alacaklar alacakform = new alacaklar();
            alacakform.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            apartmanlar menuapart = new apartmanlar();
            menuapart.Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            yenile();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.Hide();
            raporlar15 raporform = new raporlar15();
            raporform.Show();
        }
    }
}
