﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp2
{
    public partial class menuadmin : Form
    {
        string connectionString = @"Data Source=.;Initial Catalog=gnc;Integrated Security=True;TrustServerCertificate=true";
        public menuadmin()
        {
            InitializeComponent();
        }
        bool formTasiniyor = false;
        Point baslangicNoktasi = new Point(0, 0);

        private void menuadmin_Load(object sender, EventArgs e)
        {
            FetchDataFromDatabase();
            LoadDataFromDatabase();
            ResizeDataGridView();
            GetTotalConstructionCount();
            textBox1.Visible = false;
            textBox2.Visible = false;
            textBox3.Visible = false;
            label3.Visible = false;
            label4.Visible = false;
            label6.Visible = false;
            button7.Visible = false;
            button6.Visible = false;

        }
        private void ResizeDataGridView()
        {
            // Sütunların otomatik boyutlandırılmasını sağla
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            // Satırların otomatik boyutlandırılmasını sağla
            dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;

            
        }
        private void GetTotalConstructionCount()
        {
            try
            {
                // SqlConnection nesnesi oluşturma
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    // SQL sorgusu
                    string query = "SELECT COUNT(*) FROM insaat_isim WHERE insaat_adi NOT IN ('1 (İsim Ekle)', '2 (İsim Ekle)', '3 (İsim Ekle)', '4 (İsim Ekle)', '5 (İsim Ekle)', '6 (İsim Ekle)', '7 (İsim Ekle)', '8 (İsim Ekle)', '9 (İsim Ekle)', '10 (İsim Ekle)', '11 (İsim Ekle)', '12 (İsim Ekle)', '13 (İsim Ekle)', '14 (İsim Ekle)', '15 (İsim Ekle)', '16 (İsim Ekle)', 'Admin' )";


                    // SqlCommand oluşturma
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // Bağlantıyı açma
                        connection.Open();

                        // Veriyi al
                        int totalConstructionCount = (int)command.ExecuteScalar();

                        // Label'a yazdır
                        label5.Text = totalConstructionCount.ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
            }
        }
        private void LoadDataFromDatabase()
        {
            try
            {
                // SqlConnection nesnesi oluşturma
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    // SQL sorgusu
                    string query = "SELECT id as 'İD', insaat_adi as 'İnşaat İsmi' FROM insaat_isim";

                    // SqlDataAdapter nesnesi oluşturma
                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);

                    // DataTable oluşturma ve verileri yükleme
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    // DataGridView'e verileri yükleme
                    dataGridView1.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);
            }
        }
        public void FetchDataFromDatabase()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    // SQL sorgusu
                    string query = "SELECT insaat_adi FROM insaat_isim WHERE id = 1017";


                    // SqlCommand oluşturma
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // Bağlantıyı açma
                        connection.Open();

                        // Veriyi okuma
                        SqlDataReader reader = command.ExecuteReader();

                        // Veriyi oku
                        while (reader.Read())
                        {
                            // Label2'ye yazdır

                            label1.Text = reader["insaat_adi"].ToString();
                        }

                        // Okuyucuyu kapat
                        reader.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Veritabanından veri alınırken bir hata oluştu: " + ex.Message);

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Uygulamadan Çıkmak Üzeresin Devam Etmek İstiyor Musunuz?", "Emin Misin", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                System.Windows.Forms.Application.Exit();

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            this.Close();
            secim secim = new secim();
            secim.Show();
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            formTasiniyor = true;
            baslangicNoktasi = new Point(e.X, e.Y);
        }

        private void panel1_MouseEnter(object sender, EventArgs e)
        {

        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (formTasiniyor)
            {
                Point p = PointToScreen(e.Location);
                Location = new Point(p.X - this.baslangicNoktasi.X, p.Y - this.baslangicNoktasi.Y);
            }
        }

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            formTasiniyor = false;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            LoadDataFromDatabase();
            gizle();

        }
        private void gizle()
        {
            textBox1.Visible = false;
            textBox2.Visible = false;
            textBox3.Visible = false;
            label3.Visible = false;
            label4.Visible = false;
            label6.Visible = false;
            button7.Visible = false;
            button6.Visible = false;
        }
        private void temizle()
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            label3.Visible = true;
            textBox1.Visible = true;
            button6.Visible = true;
            temizle();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            // TextBox'tan ID bilgisini al
            if (!int.TryParse(textBox1.Text, out int id))
            {
                MessageBox.Show("Lütfen geçerli bir ID girin.");
                return;
            }

            // ID'yi kullanarak inşaat adını güncelle
            UpdateConstructionNameById(id);
            gizle();
        }
        private void UpdateConstructionNameById(int id)
        {
            try
            {
                // SqlConnection nesnesi oluşturma
                using (SqlConnection connection = new SqlConnection(connectionString))
                {

                    if (id.ToString() == "1")
                    {
                        try
                        {
                            // biralacak tablosundaki tüm verileri sil
                            string query1 = "DELETE FROM biralacak";
                            using (SqlConnection connection1 = new SqlConnection(connectionString))
                            {
                                SqlCommand command1 = new SqlCommand(query1, connection1);
                                connection1.Open();
                                command1.ExecuteNonQuery();
                            }

                            // birapart tablosundaki tüm verileri sil
                            string query2 = "DELETE FROM birapart";
                            using (SqlConnection connection2 = new SqlConnection(connectionString))
                            {
                                SqlCommand command2 = new SqlCommand(query2, connection2);
                                connection2.Open();
                                command2.ExecuteNonQuery();
                            }

                            // birpersonel tablosundaki tüm verileri sil
                            string query3 = "DELETE FROM birpersonel";
                            using (SqlConnection connection3 = new SqlConnection(connectionString))
                            {
                                SqlCommand command3 = new SqlCommand(query3, connection3);
                                connection3.Open();
                                command3.ExecuteNonQuery();
                            }

                            // odemebir tablosundaki tüm verileri sil
                            string query4 = "DELETE FROM odemebir";
                            using (SqlConnection connection4 = new SqlConnection(connectionString))
                            {
                                SqlCommand command4 = new SqlCommand(query4, connection4);
                                connection4.Open();
                                command4.ExecuteNonQuery();
                            }

                            MessageBox.Show("Tüm tablolardaki veriler başarıyla silindi.");
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Veriler silinirken bir hata oluştu: " + ex.Message);
                        }
                    }
                    else if (id.ToString() == "2")
                    {
                        try
                        {
                            // biralacak tablosundaki tüm verileri sil
                            string query1 = "DELETE FROM ikialacak";
                            using (SqlConnection connection1 = new SqlConnection(connectionString))
                            {
                                SqlCommand command1 = new SqlCommand(query1, connection1);
                                connection1.Open();
                                command1.ExecuteNonQuery();
                            }

                            // birapart tablosundaki tüm verileri sil
                            string query2 = "DELETE FROM ikiapart";
                            using (SqlConnection connection2 = new SqlConnection(connectionString))
                            {
                                SqlCommand command2 = new SqlCommand(query2, connection2);
                                connection2.Open();
                                command2.ExecuteNonQuery();
                            }

                            // birpersonel tablosundaki tüm verileri sil
                            string query3 = "DELETE FROM ikipersonel";
                            using (SqlConnection connection3 = new SqlConnection(connectionString))
                            {
                                SqlCommand command3 = new SqlCommand(query3, connection3);
                                connection3.Open();
                                command3.ExecuteNonQuery();
                            }

                            // odemebir tablosundaki tüm verileri sil
                            string query4 = "DELETE FROM odemeiki";
                            using (SqlConnection connection4 = new SqlConnection(connectionString))
                            {
                                SqlCommand command4 = new SqlCommand(query4, connection4);
                                connection4.Open();
                                command4.ExecuteNonQuery();
                            }

                            MessageBox.Show("Tüm tablolardaki veriler başarıyla silindi.");
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Veriler silinirken bir hata oluştu: " + ex.Message);
                        }
                    }
                    else if (id.ToString() == "3")
                    {
                        try
                        {
                            // biralacak tablosundaki tüm verileri sil
                            string query1 = "DELETE FROM ucalacak";
                            using (SqlConnection connection1 = new SqlConnection(connectionString))
                            {
                                SqlCommand command1 = new SqlCommand(query1, connection1);
                                connection1.Open();
                                command1.ExecuteNonQuery();
                            }

                            // birapart tablosundaki tüm verileri sil
                            string query2 = "DELETE FROM ucapart";
                            using (SqlConnection connection2 = new SqlConnection(connectionString))
                            {
                                SqlCommand command2 = new SqlCommand(query2, connection2);
                                connection2.Open();
                                command2.ExecuteNonQuery();
                            }

                            // birpersonel tablosundaki tüm verileri sil
                            string query3 = "DELETE FROM ucpersonel";
                            using (SqlConnection connection3 = new SqlConnection(connectionString))
                            {
                                SqlCommand command3 = new SqlCommand(query3, connection3);
                                connection3.Open();
                                command3.ExecuteNonQuery();
                            }

                            // odemebir tablosundaki tüm verileri sil
                            string query4 = "DELETE FROM odemeuc";
                            using (SqlConnection connection4 = new SqlConnection(connectionString))
                            {
                                SqlCommand command4 = new SqlCommand(query4, connection4);
                                connection4.Open();
                                command4.ExecuteNonQuery();
                            }

                            MessageBox.Show("Tüm tablolardaki veriler başarıyla silindi.");
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Veriler silinirken bir hata oluştu: " + ex.Message);
                        }
                    }
                    else if (id.ToString() == "4")
                    {
                        try
                        {
                            // biralacak tablosundaki tüm verileri sil
                            string query1 = "DELETE FROM dortalacak";
                            using (SqlConnection connection1 = new SqlConnection(connectionString))
                            {
                                SqlCommand command1 = new SqlCommand(query1, connection1);
                                connection1.Open();
                                command1.ExecuteNonQuery();
                            }

                            // birapart tablosundaki tüm verileri sil
                            string query2 = "DELETE FROM dortapart";
                            using (SqlConnection connection2 = new SqlConnection(connectionString))
                            {
                                SqlCommand command2 = new SqlCommand(query2, connection2);
                                connection2.Open();
                                command2.ExecuteNonQuery();
                            }

                            // birpersonel tablosundaki tüm verileri sil
                            string query3 = "DELETE FROM dortpersonel";
                            using (SqlConnection connection3 = new SqlConnection(connectionString))
                            {
                                SqlCommand command3 = new SqlCommand(query3, connection3);
                                connection3.Open();
                                command3.ExecuteNonQuery();
                            }

                            // odemebir tablosundaki tüm verileri sil
                            string query4 = "DELETE FROM odemedort";
                            using (SqlConnection connection4 = new SqlConnection(connectionString))
                            {
                                SqlCommand command4 = new SqlCommand(query4, connection4);
                                connection4.Open();
                                command4.ExecuteNonQuery();
                            }

                            MessageBox.Show("Tüm tablolardaki veriler başarıyla silindi.");
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Veriler silinirken bir hata oluştu: " + ex.Message);
                        }
                    }
                    else if (id.ToString() == "5")
                    {
                        try
                        {
                            // biralacak tablosundaki tüm verileri sil
                            string query1 = "DELETE FROM besalacak";
                            using (SqlConnection connection1 = new SqlConnection(connectionString))
                            {
                                SqlCommand command1 = new SqlCommand(query1, connection1);
                                connection1.Open();
                                command1.ExecuteNonQuery();
                            }

                            // birapart tablosundaki tüm verileri sil
                            string query2 = "DELETE FROM besapart";
                            using (SqlConnection connection2 = new SqlConnection(connectionString))
                            {
                                SqlCommand command2 = new SqlCommand(query2, connection2);
                                connection2.Open();
                                command2.ExecuteNonQuery();
                            }

                            // birpersonel tablosundaki tüm verileri sil
                            string query3 = "DELETE FROM bespersonel";
                            using (SqlConnection connection3 = new SqlConnection(connectionString))
                            {
                                SqlCommand command3 = new SqlCommand(query3, connection3);
                                connection3.Open();
                                command3.ExecuteNonQuery();
                            }

                            // odemebir tablosundaki tüm verileri sil
                            string query4 = "DELETE FROM odemebes";
                            using (SqlConnection connection4 = new SqlConnection(connectionString))
                            {
                                SqlCommand command4 = new SqlCommand(query4, connection4);
                                connection4.Open();
                                command4.ExecuteNonQuery();
                            }

                            MessageBox.Show("Tüm tablolardaki veriler başarıyla silindi.");
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Veriler silinirken bir hata oluştu: " + ex.Message);
                        }
                    }
                    else if (id.ToString() == "6")
                    {
                        try
                        {
                            // biralacak tablosundaki tüm verileri sil
                            string query1 = "DELETE FROM altialacak";
                            using (SqlConnection connection1 = new SqlConnection(connectionString))
                            {
                                SqlCommand command1 = new SqlCommand(query1, connection1);
                                connection1.Open();
                                command1.ExecuteNonQuery();
                            }

                            // birapart tablosundaki tüm verileri sil
                            string query2 = "DELETE FROM altiapart";
                            using (SqlConnection connection2 = new SqlConnection(connectionString))
                            {
                                SqlCommand command2 = new SqlCommand(query2, connection2);
                                connection2.Open();
                                command2.ExecuteNonQuery();
                            }

                            // birpersonel tablosundaki tüm verileri sil
                            string query3 = "DELETE FROM altipersonel";
                            using (SqlConnection connection3 = new SqlConnection(connectionString))
                            {
                                SqlCommand command3 = new SqlCommand(query3, connection3);
                                connection3.Open();
                                command3.ExecuteNonQuery();
                            }

                            // odemebir tablosundaki tüm verileri sil
                            string query4 = "DELETE FROM odemealti";
                            using (SqlConnection connection4 = new SqlConnection(connectionString))
                            {
                                SqlCommand command4 = new SqlCommand(query4, connection4);
                                connection4.Open();
                                command4.ExecuteNonQuery();
                            }

                            MessageBox.Show("Tüm tablolardaki veriler başarıyla silindi.");
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Veriler silinirken bir hata oluştu: " + ex.Message);
                        }
                    }
                    else if (id.ToString() == "7")
                    {
                        try
                        {
                            // biralacak tablosundaki tüm verileri sil
                            string query1 = "DELETE FROM yedialacak";
                            using (SqlConnection connection1 = new SqlConnection(connectionString))
                            {
                                SqlCommand command1 = new SqlCommand(query1, connection1);
                                connection1.Open();
                                command1.ExecuteNonQuery();
                            }

                            // birapart tablosundaki tüm verileri sil
                            string query2 = "DELETE FROM yediapart";
                            using (SqlConnection connection2 = new SqlConnection(connectionString))
                            {
                                SqlCommand command2 = new SqlCommand(query2, connection2);
                                connection2.Open();
                                command2.ExecuteNonQuery();
                            }

                            // birpersonel tablosundaki tüm verileri sil
                            string query3 = "DELETE FROM yedipersonel";
                            using (SqlConnection connection3 = new SqlConnection(connectionString))
                            {
                                SqlCommand command3 = new SqlCommand(query3, connection3);
                                connection3.Open();
                                command3.ExecuteNonQuery();
                            }

                            // odemebir tablosundaki tüm verileri sil
                            string query4 = "DELETE FROM odemeyedi";
                            using (SqlConnection connection4 = new SqlConnection(connectionString))
                            {
                                SqlCommand command4 = new SqlCommand(query4, connection4);
                                connection4.Open();
                                command4.ExecuteNonQuery();
                            }

                            MessageBox.Show("Tüm tablolardaki veriler başarıyla silindi.");
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Veriler silinirken bir hata oluştu: " + ex.Message);
                        }
                    }
                    else if (id.ToString() == "8")
                    {
                        try
                        {
                            // biralacak tablosundaki tüm verileri sil
                            string query1 = "DELETE FROM sekizalacak";
                            using (SqlConnection connection1 = new SqlConnection(connectionString))
                            {
                                SqlCommand command1 = new SqlCommand(query1, connection1);
                                connection1.Open();
                                command1.ExecuteNonQuery();
                            }

                            // birapart tablosundaki tüm verileri sil
                            string query2 = "DELETE FROM sekizapart";
                            using (SqlConnection connection2 = new SqlConnection(connectionString))
                            {
                                SqlCommand command2 = new SqlCommand(query2, connection2);
                                connection2.Open();
                                command2.ExecuteNonQuery();
                            }

                            // birpersonel tablosundaki tüm verileri sil
                            string query3 = "DELETE FROM sekizpersonel";
                            using (SqlConnection connection3 = new SqlConnection(connectionString))
                            {
                                SqlCommand command3 = new SqlCommand(query3, connection3);
                                connection3.Open();
                                command3.ExecuteNonQuery();
                            }

                            // odemebir tablosundaki tüm verileri sil
                            string query4 = "DELETE FROM odemesekiz";
                            using (SqlConnection connection4 = new SqlConnection(connectionString))
                            {
                                SqlCommand command4 = new SqlCommand(query4, connection4);
                                connection4.Open();
                                command4.ExecuteNonQuery();
                            }

                            MessageBox.Show("Tüm tablolardaki veriler başarıyla silindi.");
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Veriler silinirken bir hata oluştu: " + ex.Message);
                        }
                    }
                    else if (id.ToString() == "9")
                    {
                        try
                        {
                            // biralacak tablosundaki tüm verileri sil
                            string query1 = "DELETE FROM dokuzalacak";
                            using (SqlConnection connection1 = new SqlConnection(connectionString))
                            {
                                SqlCommand command1 = new SqlCommand(query1, connection1);
                                connection1.Open();
                                command1.ExecuteNonQuery();
                            }

                            // birapart tablosundaki tüm verileri sil
                            string query2 = "DELETE FROM dokuzapart";
                            using (SqlConnection connection2 = new SqlConnection(connectionString))
                            {
                                SqlCommand command2 = new SqlCommand(query2, connection2);
                                connection2.Open();
                                command2.ExecuteNonQuery();
                            }

                            // birpersonel tablosundaki tüm verileri sil
                            string query3 = "DELETE FROM dokuzpersonel";
                            using (SqlConnection connection3 = new SqlConnection(connectionString))
                            {
                                SqlCommand command3 = new SqlCommand(query3, connection3);
                                connection3.Open();
                                command3.ExecuteNonQuery();
                            }

                            // odemebir tablosundaki tüm verileri sil
                            string query4 = "DELETE FROM odemedokuz";
                            using (SqlConnection connection4 = new SqlConnection(connectionString))
                            {
                                SqlCommand command4 = new SqlCommand(query4, connection4);
                                connection4.Open();
                                command4.ExecuteNonQuery();
                            }

                            MessageBox.Show("Tüm tablolardaki veriler başarıyla silindi.");
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Veriler silinirken bir hata oluştu: " + ex.Message);
                        }
                    }
                    else if (id.ToString() == "10")
                    {
                        try
                        {
                            // biralacak tablosundaki tüm verileri sil
                            string query1 = "DELETE FROM onalacak";
                            using (SqlConnection connection1 = new SqlConnection(connectionString))
                            {
                                SqlCommand command1 = new SqlCommand(query1, connection1);
                                connection1.Open();
                                command1.ExecuteNonQuery();
                            }

                            // birapart tablosundaki tüm verileri sil
                            string query2 = "DELETE FROM onapart";
                            using (SqlConnection connection2 = new SqlConnection(connectionString))
                            {
                                SqlCommand command2 = new SqlCommand(query2, connection2);
                                connection2.Open();
                                command2.ExecuteNonQuery();
                            }

                            // birpersonel tablosundaki tüm verileri sil
                            string query3 = "DELETE FROM onpersonel";
                            using (SqlConnection connection3 = new SqlConnection(connectionString))
                            {
                                SqlCommand command3 = new SqlCommand(query3, connection3);
                                connection3.Open();
                                command3.ExecuteNonQuery();
                            }

                            // odemebir tablosundaki tüm verileri sil
                            string query4 = "DELETE FROM odemeon";
                            using (SqlConnection connection4 = new SqlConnection(connectionString))
                            {
                                SqlCommand command4 = new SqlCommand(query4, connection4);
                                connection4.Open();
                                command4.ExecuteNonQuery();
                            }

                            MessageBox.Show("Tüm tablolardaki veriler başarıyla silindi.");
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Veriler silinirken bir hata oluştu: " + ex.Message);
                        }
                    }
                    else if (id.ToString() == "11")
                    {
                        try
                        {
                            // biralacak tablosundaki tüm verileri sil
                            string query1 = "DELETE FROM onbiralacak";
                            using (SqlConnection connection1 = new SqlConnection(connectionString))
                            {
                                SqlCommand command1 = new SqlCommand(query1, connection1);
                                connection1.Open();
                                command1.ExecuteNonQuery();
                            }

                            // birapart tablosundaki tüm verileri sil
                            string query2 = "DELETE FROM onbirapart";
                            using (SqlConnection connection2 = new SqlConnection(connectionString))
                            {
                                SqlCommand command2 = new SqlCommand(query2, connection2);
                                connection2.Open();
                                command2.ExecuteNonQuery();
                            }

                            // birpersonel tablosundaki tüm verileri sil
                            string query3 = "DELETE FROM onbirpersonel";
                            using (SqlConnection connection3 = new SqlConnection(connectionString))
                            {
                                SqlCommand command3 = new SqlCommand(query3, connection3);
                                connection3.Open();
                                command3.ExecuteNonQuery();
                            }

                            // odemebir tablosundaki tüm verileri sil
                            string query4 = "DELETE FROM odemeonbir";
                            using (SqlConnection connection4 = new SqlConnection(connectionString))
                            {
                                SqlCommand command4 = new SqlCommand(query4, connection4);
                                connection4.Open();
                                command4.ExecuteNonQuery();
                            }

                            MessageBox.Show("Tüm tablolardaki veriler başarıyla silindi.");
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Veriler silinirken bir hata oluştu: " + ex.Message);
                        }
                    }
                    else if (id.ToString() == "12")
                    {
                        try
                        {
                            // biralacak tablosundaki tüm verileri sil
                            string query1 = "DELETE FROM onikialacak";
                            using (SqlConnection connection1 = new SqlConnection(connectionString))
                            {
                                SqlCommand command1 = new SqlCommand(query1, connection1);
                                connection1.Open();
                                command1.ExecuteNonQuery();
                            }

                            // birapart tablosundaki tüm verileri sil
                            string query2 = "DELETE FROM onikiapart";
                            using (SqlConnection connection2 = new SqlConnection(connectionString))
                            {
                                SqlCommand command2 = new SqlCommand(query2, connection2);
                                connection2.Open();
                                command2.ExecuteNonQuery();
                            }

                            // birpersonel tablosundaki tüm verileri sil
                            string query3 = "DELETE FROM onikipersonel";
                            using (SqlConnection connection3 = new SqlConnection(connectionString))
                            {
                                SqlCommand command3 = new SqlCommand(query3, connection3);
                                connection3.Open();
                                command3.ExecuteNonQuery();
                            }

                            // odemebir tablosundaki tüm verileri sil
                            string query4 = "DELETE FROM odemeoniki";
                            using (SqlConnection connection4 = new SqlConnection(connectionString))
                            {
                                SqlCommand command4 = new SqlCommand(query4, connection4);
                                connection4.Open();
                                command4.ExecuteNonQuery();
                            }

                            MessageBox.Show("Tüm tablolardaki veriler başarıyla silindi.");
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Veriler silinirken bir hata oluştu: " + ex.Message);
                        }
                    }
                    else if (id.ToString() == "13")
                    {
                        try
                        {
                            // biralacak tablosundaki tüm verileri sil
                            string query1 = "DELETE FROM onucalacak";
                            using (SqlConnection connection1 = new SqlConnection(connectionString))
                            {
                                SqlCommand command1 = new SqlCommand(query1, connection1);
                                connection1.Open();
                                command1.ExecuteNonQuery();
                            }

                            // birapart tablosundaki tüm verileri sil
                            string query2 = "DELETE FROM onucapart";
                            using (SqlConnection connection2 = new SqlConnection(connectionString))
                            {
                                SqlCommand command2 = new SqlCommand(query2, connection2);
                                connection2.Open();
                                command2.ExecuteNonQuery();
                            }

                            // birpersonel tablosundaki tüm verileri sil
                            string query3 = "DELETE FROM onucpersonel";
                            using (SqlConnection connection3 = new SqlConnection(connectionString))
                            {
                                SqlCommand command3 = new SqlCommand(query3, connection3);
                                connection3.Open();
                                command3.ExecuteNonQuery();
                            }

                            // odemebir tablosundaki tüm verileri sil
                            string query4 = "DELETE FROM odemeonuc";
                            using (SqlConnection connection4 = new SqlConnection(connectionString))
                            {
                                SqlCommand command4 = new SqlCommand(query4, connection4);
                                connection4.Open();
                                command4.ExecuteNonQuery();
                            }

                            MessageBox.Show("Tüm tablolardaki veriler başarıyla silindi.");
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Veriler silinirken bir hata oluştu: " + ex.Message);
                        }
                    }
                    else if (id.ToString() == "14")
                    {
                        try
                        {
                            // biralacak tablosundaki tüm verileri sil
                            string query1 = "DELETE FROM ondortalacak";
                            using (SqlConnection connection1 = new SqlConnection(connectionString))
                            {
                                SqlCommand command1 = new SqlCommand(query1, connection1);
                                connection1.Open();
                                command1.ExecuteNonQuery();
                            }

                            // birapart tablosundaki tüm verileri sil
                            string query2 = "DELETE FROM ondortapart";
                            using (SqlConnection connection2 = new SqlConnection(connectionString))
                            {
                                SqlCommand command2 = new SqlCommand(query2, connection2);
                                connection2.Open();
                                command2.ExecuteNonQuery();
                            }

                            // birpersonel tablosundaki tüm verileri sil
                            string query3 = "DELETE FROM ondortpersonel";
                            using (SqlConnection connection3 = new SqlConnection(connectionString))
                            {
                                SqlCommand command3 = new SqlCommand(query3, connection3);
                                connection3.Open();
                                command3.ExecuteNonQuery();
                            }

                            // odemebir tablosundaki tüm verileri sil
                            string query4 = "DELETE FROM odemeondort";
                            using (SqlConnection connection4 = new SqlConnection(connectionString))
                            {
                                SqlCommand command4 = new SqlCommand(query4, connection4);
                                connection4.Open();
                                command4.ExecuteNonQuery();
                            }

                            MessageBox.Show("Tüm tablolardaki veriler başarıyla silindi.");
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Veriler silinirken bir hata oluştu: " + ex.Message);
                        }
                    }
                    else if (id.ToString() == "15")
                    {
                        try
                        {
                            // biralacak tablosundaki tüm verileri sil
                            string query1 = "DELETE FROM onbesalacak";
                            using (SqlConnection connection1 = new SqlConnection(connectionString))
                            {
                                SqlCommand command1 = new SqlCommand(query1, connection1);
                                connection1.Open();
                                command1.ExecuteNonQuery();
                            }

                            // birapart tablosundaki tüm verileri sil
                            string query2 = "DELETE FROM onbesapart";
                            using (SqlConnection connection2 = new SqlConnection(connectionString))
                            {
                                SqlCommand command2 = new SqlCommand(query2, connection2);
                                connection2.Open();
                                command2.ExecuteNonQuery();
                            }

                            // birpersonel tablosundaki tüm verileri sil
                            string query3 = "DELETE FROM onbespersonel";
                            using (SqlConnection connection3 = new SqlConnection(connectionString))
                            {
                                SqlCommand command3 = new SqlCommand(query3, connection3);
                                connection3.Open();
                                command3.ExecuteNonQuery();
                            }

                            // odemebir tablosundaki tüm verileri sil
                            string query4 = "DELETE FROM odemeonbes";
                            using (SqlConnection connection4 = new SqlConnection(connectionString))
                            {
                                SqlCommand command4 = new SqlCommand(query4, connection4);
                                connection4.Open();
                                command4.ExecuteNonQuery();
                            }

                            MessageBox.Show("Tüm tablolardaki veriler başarıyla silindi.");
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Veriler silinirken bir hata oluştu: " + ex.Message);
                        }
                    }
                    // SQL sorgusu
                    string query = "UPDATE insaat_isim SET insaat_adi = @NewName WHERE id = @id";

                    // SqlCommand oluşturma
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // Parametreleri ekleyerek SQL sorgusunu güvenli hale getirme
                        command.Parameters.AddWithValue("@NewName", id + " (İsim Ekle)");
                        command.Parameters.AddWithValue("@id", id);

                        // Bağlantıyı açma
                        connection.Open();

                        // SQL sorgusunu çalıştırma
                        int rowsAffected = command.ExecuteNonQuery();

                        // Güncelleme başarılı ise
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("İnşaat Başarıyla Silindi!");
                            LoadDataFromDatabase();
                            GetTotalConstructionCount();
                        }
                        else
                        {
                            MessageBox.Show("Silinecek inşaat bulunamadı!");
                            LoadDataFromDatabase();
                            GetTotalConstructionCount();
                            gizle();
                            temizle();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Veritabanında güncelleme yapılırken bir hata oluştu: " + ex.Message);
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            // TextBox'tan ID ve yeni ad bilgilerini al
            if (!int.TryParse(textBox2.Text, out int id))
            {
                MessageBox.Show("Lütfen geçerli bir ID girin.");
                LoadDataFromDatabase();
                GetTotalConstructionCount();
                gizle();
                temizle();
                return;
            }

            string newName = textBox3.Text.Trim();

            // ID'yi ve yeni adı kullanarak inşaat adını güncelle
            UpdateConstructionNameById(id, newName);

        }
        private void UpdateConstructionNameById(int id, string newName)
        {
            try
            {
                // SqlConnection nesnesi oluşturma
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    // SQL sorgusu
                    string query = "UPDATE insaat_isim SET insaat_adi = @NewName WHERE id = @id";

                    // SqlCommand oluşturma
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // Parametreleri ekleyerek SQL sorgusunu güvenli hale getirme
                        command.Parameters.AddWithValue("@NewName", newName);
                        command.Parameters.AddWithValue("@id", id);

                        // Bağlantıyı açma
                        connection.Open();

                        // SQL sorgusunu çalıştırma
                        int rowsAffected = command.ExecuteNonQuery();

                        // Güncelleme başarılı ise
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("İnşaat adı güncellendi!");
                            LoadDataFromDatabase();
                            GetTotalConstructionCount();
                            gizle();
                            temizle();

                        }
                        else
                        {
                            MessageBox.Show("Güncellenecek inşaat bulunamadı!");
                            LoadDataFromDatabase();
                            GetTotalConstructionCount();
                            gizle();
                            temizle();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Veritabanında güncelleme yapılırken bir hata oluştu: " + ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            label4.Visible = true;
            label6.Visible = true;
            textBox2.Visible = true;
            textBox3.Visible = true;
            button7.Visible=true;
        }

        private void button8_Click(object sender, EventArgs e)
        {

        }
    }
    
}


